#include "storage.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/l2cap.h>
#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/atomic.h>

#include "sdcard.h"
#include "transport.h"
#include "utils.h"

LOG_MODULE_REGISTER(storage, CONFIG_LOG_DEFAULT_LEVEL);

#define MAX_PACKET_LENGTH 256
#define OPUS_ENTRY_LENGTH 80
#define FRAME_PREFIX_LENGTH 3

#define READ_COMMAND 0
#define DELETE_COMMAND 1
#define NUKE 2
#define STOP_COMMAND 3

#define INVALID_FILE_SIZE 3
#define ZERO_FILE_SIZE 4
#define INVALID_OFFSET 5
#define INVALID_COMMAND 6
#define ACK_STALE 7
#define ACK_OUT_OF_RANGE 8
#define STORAGE_FAILURE 9
#define ACK_DURABLE 200
#define ACK_PENDING_INTERNAL 255

#define MAX_HEARTBEAT_FRAMES 100
#define HEARTBEAT 50
static void storage_config_changed_handler(const struct bt_gatt_attr *attr, uint16_t value);
static ssize_t storage_write_handler(struct bt_conn *conn,
                                     const struct bt_gatt_attr *attr,
                                     const void *buf,
                                     uint16_t len,
                                     uint16_t offset,
                                     uint8_t flags);

static struct bt_uuid_128 storage_service_uuid =
    BT_UUID_INIT_128(BT_UUID_128_ENCODE(0x30295780, 0x4301, 0xEABD, 0x2904, 0x2849ADFEAE43));
static struct bt_uuid_128 storage_write_uuid =
    BT_UUID_INIT_128(BT_UUID_128_ENCODE(0x30295781, 0x4301, 0xEABD, 0x2904, 0x2849ADFEAE43));
static struct bt_uuid_128 storage_read_uuid =
    BT_UUID_INIT_128(BT_UUID_128_ENCODE(0x30295782, 0x4301, 0xEABD, 0x2904, 0x2849ADFEAE43));
static ssize_t storage_read_characteristic(struct bt_conn *conn,
                                           const struct bt_gatt_attr *attr,
                                           void *buf,
                                           uint16_t len,
                                           uint16_t offset);

K_THREAD_STACK_DEFINE(storage_stack, 4096);
static struct k_thread storage_thread;

extern uint8_t file_count;
extern uint32_t file_num_array[2];
void broadcast_storage_packet(struct k_work *work_item);

static struct bt_gatt_attr storage_service_attr[] = {
    BT_GATT_PRIMARY_SERVICE(&storage_service_uuid),
    BT_GATT_CHARACTERISTIC(&storage_write_uuid.uuid,
                           BT_GATT_CHRC_WRITE | BT_GATT_CHRC_NOTIFY,
                           BT_GATT_PERM_WRITE_ENCRYPT,
                           NULL,
                           storage_write_handler,
                           NULL),
    BT_GATT_CCC(storage_config_changed_handler,
                BT_GATT_PERM_READ_ENCRYPT | BT_GATT_PERM_WRITE_ENCRYPT),
    BT_GATT_CHARACTERISTIC(&storage_read_uuid.uuid,
                           BT_GATT_CHRC_READ | BT_GATT_CHRC_NOTIFY,
                           BT_GATT_PERM_READ_ENCRYPT,
                           storage_read_characteristic,
                           NULL,
                           NULL),
    BT_GATT_CCC(storage_config_changed_handler,
                BT_GATT_PERM_READ_ENCRYPT | BT_GATT_PERM_WRITE_ENCRYPT),

};

struct bt_gatt_service storage_service = BT_GATT_SERVICE(storage_service_attr);

bool storage_is_on = false;

static int notify_storage_owner(struct bt_conn *conn, const void *data, uint16_t len)
{
    if (!transport_peer_is_authorized(conn)) {
        return -EACCES;
    }

    /* attrs[1] is the characteristic declaration; attrs[2] is its value. */
    return bt_gatt_notify(conn, &storage_service.attrs[2], data, len);
}

static void storage_config_changed_handler(const struct bt_gatt_attr *attr, uint16_t value)
{
    struct bt_conn *conn = get_current_connection();
    bool authorized = transport_peer_is_authorized(conn);
    if (conn != NULL) {
        bt_conn_unref(conn);
    }

    if (!authorized) {
        storage_is_on = false;
        LOG_WRN("Ignored backlog subscription from unauthorized peer");
        return;
    }

    if (value == BT_GATT_CCC_NOTIFY) {
        storage_is_on = true;
        LOG_INF("Client subscribed for notifications");
    } else if (value == 0) {
        storage_is_on = false;
        LOG_INF("Client unsubscribed from notifications");
    } else {
        LOG_ERR("Invalid CCC value: %u", value);
    }
}

static ssize_t storage_read_characteristic(struct bt_conn *conn,
                                           const struct bt_gatt_attr *attr,
                                           void *buf,
                                           uint16_t len,
                                           uint16_t offset)
{
    if (!transport_peer_is_authorized(conn)) {
        return BT_GATT_ERR(BT_ATT_ERR_AUTHORIZATION);
    }

    k_msleep(10);
    /* Preserve the legacy first eight bytes (absolute byte tail/head). QSPI
     * clients can read the extension as generation, head sequence, tail
     * sequence, persistent loss-event count, and status flags. */
    uint32_t amount[7] = {file_num_array[0], file_num_array[1],
                          0U, 0U, 0U, 0U, 0U};
    size_t status_length = 2U * sizeof(uint32_t);
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
    if (qspi_backlog_get_status(&amount[2], &amount[3], &amount[4],
                                &amount[5], &amount[6]) == 0) {
        status_length = sizeof(amount);
    }
#endif
    ssize_t result = bt_gatt_attr_read(conn, attr, buf, len, offset,
                                       amount, status_length);
    return result;
}

uint8_t transport_started = 0;

#define SD_BLE_SIZE 440
static uint8_t storage_write_buffer[SD_BLE_SIZE];

static uint32_t offset = 0;
static uint8_t stop_started = 0;
static uint8_t delete_started = 0;
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
struct qspi_ack_token {
    uint32_t generation;
    uint32_t target_sequence;
};
K_MSGQ_DEFINE(qspi_ack_queue, sizeof(struct qspi_ack_token), 4, 4);
#endif
static uint8_t current_read_num = 1;
uint32_t remaining_length = 0;

static int setup_storage_tx()
{
    transport_started = (uint8_t) 0;
    // offset = 0;
    LOG_INF("about to transmit storage\n");
    k_msleep(1000);
    int res = move_read_pointer(current_read_num);
    if (res) {
        LOG_INF("bad pointer");
        transport_started = 0;
        current_read_num = 1;
        remaining_length = 0;
        return -1;
    }

    LOG_INF("current read ptr %d", current_read_num);

    remaining_length = file_num_array[current_read_num - 1];
    if (current_read_num == file_count) {
        remaining_length = get_file_size(file_count);
    }

    if (offset > remaining_length) {
        LOG_ERR("Saved/requested offset is beyond file size");
        offset = 0;
    }
    remaining_length -= offset;

    // offset=offset_;
    LOG_INF("remaining length: %d", remaining_length);
    LOG_INF("offset: %d", offset);
    LOG_INF("file: %d", current_read_num);

    return 0;
}
uint8_t delete_num = 0;
uint8_t nuke_started = 0;
static uint8_t heartbeat_count = 0;
static uint32_t read_be32(const uint8_t *bytes)
{
    return ((uint32_t)bytes[0] << 24) | ((uint32_t)bytes[1] << 16) |
           ((uint32_t)bytes[2] << 8) | (uint32_t)bytes[3];
}

static uint8_t parse_storage_command(const void *buf, uint16_t len)
{

    if (len != 6 && len != 2
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
        && len != 10
#endif
    ) {
        LOG_INF("invalid command");
        return INVALID_COMMAND;
    }
    const uint8_t command = ((uint8_t *) buf)[0];
    const uint8_t file_num = ((uint8_t *) buf)[1];
    uint32_t size = 0;
    if (len == 6) {
        size = read_be32((const uint8_t *)buf + 2);
    }
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
    if (len == 10 && command == DELETE_COMMAND && file_num == 1U) {
        const uint8_t *bytes = buf;
        const struct qspi_ack_token token = {
            .generation = read_be32(bytes + 2),
            .target_sequence = read_be32(bytes + 6),
        };
        /* A queue slot owns the complete token. Never overwrite an in-flight
         * ACK, and never emit acceptance before the storage thread commits. */
        return k_msgq_put(&qspi_ack_queue, &token, K_NO_WAIT) == 0 ?
                   ACK_PENDING_INTERNAL : STORAGE_FAILURE;
    }
#endif
    if (len == 10) {
        return INVALID_COMMAND;
    }
    LOG_PRINTK("storage command: command: %d file: %d value: %d\n",
               command, file_num, size);

    if (file_num == 0) {
        LOG_INF("invalid file count 0");
        return INVALID_FILE_SIZE;
    }
    if (file_num > file_count) // invalid file count
    {
        LOG_INF("invalid file count");
        return INVALID_FILE_SIZE;
        // add audio all?
    }
    if (command == READ_COMMAND) // read
    {
        uint32_t temp = file_num == file_count ? get_file_size(file_num)
                                               : file_num_array[file_num - 1];
        file_num_array[file_num - 1] = temp;
        if (size > temp) {
            LOG_INF("requested offset is beyond file size");
            return INVALID_OFFSET;
        }
        if (file_num == (file_count)) {
            LOG_INF("file_count == final file");
            offset = size - (size % SD_BLE_SIZE); // round down to nearest SD_BLE_SIZE
            current_read_num = file_num;
            transport_started = 1;
        } else if (temp == 0) {
            LOG_INF("file size is 0");
            return ZERO_FILE_SIZE;
        } else {
            LOG_INF("valid command, setting up ");
            offset = size - (size % SD_BLE_SIZE);
            current_read_num = file_num;
            transport_started = 1;
        }
    } else if (command == DELETE_COMMAND) {
        delete_num = file_num;
        delete_started = 1;
    } else if (command == NUKE) {
        nuke_started = 1;
    } else if (command == STOP_COMMAND) // should be no explicit stop command, send heartbeats to keep connection alive
    {
        remaining_length = 0;
        stop_started = 1;
    } else if (command == HEARTBEAT) {
        heartbeat_count = 0;
    } else {
        LOG_INF("invalid command \n");
        return 6;
    }
    return 0;
}

static ssize_t storage_write_handler(struct bt_conn *conn,
                                     const struct bt_gatt_attr *attr,
                                     const void *buf,
                                     uint16_t len,
                                     uint16_t offset,
                                     uint8_t flags)
{
    if (!transport_peer_is_authorized(conn)) {
        return BT_GATT_ERR(BT_ATT_ERR_AUTHORIZATION);
    }

    LOG_INF("about to schedule the storage");
    if (len > 0U) {
        LOG_INF("was sent %d", ((const uint8_t *) buf)[0]);
    }

    uint8_t result_buffer[1] = {0};
    uint8_t result = parse_storage_command(buf, len);
    result_buffer[0] = result;
    LOG_INF("length of storage write: %d", len);
    LOG_INF("result: %d ", result);
    if (result != ACK_PENDING_INTERNAL) {
        (void) notify_storage_owner(conn, &result_buffer, 1);
    }
    return len;
}

// static void write_to_gatt(struct bt_conn *conn)
// {
//     uint32_t id = packet_next_index++;
//     index = 0;
//     storage_write_buffer[0] = id & 0xFF;
//     storage_write_buffer[1] = (id >> 8) & 0xFF;
//     storage_write_buffer[2] = index;

//     const uint32_t packet_size = MIN(remaining_length,OPUS_ENTRY_LENGTH);

//     int r = read_audio_data(storage_write_buffer+FRAME_PREFIX_LENGTH,packet_size,offset);
//     offset = offset + packet_size;

//     index++;

//     int err = bt_gatt_notify(conn, &storage_service.attrs[1], &storage_write_buffer,packet_size+FRAME_PREFIX_LENGTH);
//     if (err)
//     {
//         LOG_PRINTK("error writing to gatt: %d\n",err);
//     }
//     else
//     {
//     remaining_length = remaining_length - OPUS_ENTRY_LENGTH;
//     }
// }

static void write_to_gatt(struct bt_conn *conn)
{
    if (!transport_peer_is_authorized(conn)) {
        remaining_length = 0;
        save_offset(offset);
        return;
    }

    /* A notification value may contain at most ATT_MTU - 3 bytes.  iPhones do
     * not promise the 443-byte ATT MTU that the inherited Omi implementation
     * assumed.  Preserve the on-disk 440-byte records, but stream each record
     * in negotiated-MTU-sized pieces.  The client commits only complete
     * 440-byte records, so reconnecting from the rounded-down offset is safe. */
    const uint16_t att_mtu = bt_gatt_get_mtu(conn);
    const uint16_t notify_capacity = att_mtu > 3U ? att_mtu - 3U : 0U;
    if (notify_capacity < 2U) {
        LOG_WRN("ATT MTU %u cannot carry backlog data", att_mtu);
        k_sleep(K_MSEC(5));
        return;
    }

    uint32_t packet_size = MIN(remaining_length, MIN((uint32_t) SD_BLE_SIZE,
                                                     (uint32_t) notify_capacity));
    /* One-byte notifications are control/status values in the legacy protocol.
     * Avoid leaving a final one-byte data fragment that a phone would mistake
     * for ACK (0) or transfer-complete (100). */
    if (remaining_length > packet_size && remaining_length - packet_size == 1U) {
        packet_size--;
    }

    int r = read_audio_data(storage_write_buffer, packet_size, offset);
    if (r < 0 || (uint32_t) r != packet_size) {
        LOG_ERR("Failed to read backlog block: %d", r);
        remaining_length = 0;
        save_offset(offset);
        return;
    }
    int err = notify_storage_owner(conn, &storage_write_buffer, packet_size);
    if (err) {
        LOG_PRINTK("error writing to gatt: %d\n", err);
        /* Notification buffers are finite.  Keep the same offset and retry; a
         * disconnect will resume from the client's last complete 440-B block. */
        k_sleep(K_MSEC(5));
    } else {
        offset += packet_size;
        remaining_length -= packet_size;
    }
    // LOG_PRINTK("wrote to gatt %d\n",err);
}

void storage_write(void)
{
    while (1) {
        struct bt_conn *conn = get_current_connection();
        bool conn_authorized = transport_peer_is_authorized(conn);

        if (!conn_authorized) {
            if (remaining_length > 0U) {
                save_offset(offset);
            }
            remaining_length = 0U;
            transport_started = 0U;
            storage_is_on = false;
        }

        if (transport_started && conn_authorized) {
            LOG_INF("transpor started in side : %d", transport_started);
            setup_storage_tx();
        }
        // probably prefer to implement using work orders for delete,nuke,etc...
        if (delete_started) {
            LOG_INF("delete:%d\n", delete_started);
            int err = transport_clear_offline_audio();
            offset = 0;
            remaining_length = 0;

            if (err) {
                LOG_PRINTK("error clearing\n");
            } else {
                uint8_t result_buffer[1] = {200};
                if (conn_authorized) {
                    (void) notify_storage_owner(conn, &result_buffer, 1);
                }
            }
            delete_started = 0;
            k_msleep(10);
        }
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
        struct qspi_ack_token token;
        if (k_msgq_get(&qspi_ack_queue, &token, K_NO_WAIT) == 0) {
            int err = qspi_backlog_ack(token.generation, token.target_sequence);
            uint8_t result = ACK_DURABLE;
            if (err == -ESTALE) {
                result = ACK_STALE;
            } else if (err == -ERANGE) {
                result = ACK_OUT_OF_RANGE;
            } else if (err != 0) {
                result = STORAGE_FAILURE;
            }
            if (conn_authorized) {
                (void) notify_storage_owner(conn, &result, 1);
            }
        }
#endif
        if (nuke_started) {
            int err = transport_clear_offline_audio();
            offset = 0;
            remaining_length = 0;
            if (err) {
                LOG_ERR("Failed to clear offline backlog: %d", err);
            }
            nuke_started = 0;
        }
        if (stop_started) {
            remaining_length = 0;
            stop_started = 0;
            save_offset(offset);
        }
        if (heartbeat_count == MAX_HEARTBEAT_FRAMES) {
            LOG_PRINTK("no heartbeat sent\n");
            save_offset(offset);
            // k_yield();
            // continue;
        }

        if (remaining_length > 0 && conn_authorized) {
            // LOG_PRINTK("remaining length: %d\n",remaining_length);

            write_to_gatt(conn);
            heartbeat_count = (heartbeat_count + 1) % (MAX_HEARTBEAT_FRAMES + 1);

            transport_started = 0;
            if (remaining_length == 0) {
                if (stop_started) {
                    stop_started = 0;
                } else {
                    LOG_PRINTK("done. attempting to download more files\n");
                    uint8_t stop_result[1] = {100};
                    int err = notify_storage_owner(conn, &stop_result, 1);
                    if (err) {
                        LOG_WRN("Failed to send backlog stop marker: %d", err);
                    }
                    k_sleep(K_MSEC(10));
                }
            }
        }
        if (conn != NULL) {
            bt_conn_unref(conn);
        }
        k_yield();
    }
}

int storage_init()
{
    k_thread_create(&storage_thread,
                    storage_stack,
                    K_THREAD_STACK_SIZEOF(storage_stack),
                    (k_thread_entry_t) storage_write,
                    NULL,
                    NULL,
                    NULL,
                    K_PRIO_PREEMPT(7),
                    0,
                    K_NO_WAIT);
    return 0;
}
