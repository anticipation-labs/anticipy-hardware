# Flash and factory reset

## Flash one pendant

1. Plug the XIAO nRF52840 Sense into a Mac with a USB data cable.
2. Double-tap its tiny reset button. A drive named `XIAO-SENSE` should appear.
3. Drag `Anticipy_Tuesday_EVT_v0.9.1.uf2` onto that drive, or run `./flash.sh` in Terminal.
4. The drive disconnects automatically. Unplug and power the pendant from its battery.
5. On the iPhone, open Anticipy, select the nearby pendant, accept the Bluetooth pairing prompt, then press **Test vibration**.

If `XIAO-SENSE` does not appear, try another cable; many charging cables have no data wires.

## Clear the factory phone before handoff

This gesture is intentionally hard to trigger by accident and only works during boot:

1. Turn the pendant fully off.
2. Press and keep holding the pendant button.
3. Turn the pendant on while continuing to hold the button.
4. Keep holding until green lights. The protected hold itself is 8 seconds, but the normal boot lights run first, so expect roughly 11–12 seconds from power-on.
5. When green lights, release the button.
6. The pendant deletes its saved BLE bond and offline audio, then reboots.
7. On the factory iPhone, open **Settings → Bluetooth**, tap the old Anticipy entry, and choose **Forget This Device**.
8. Confirm a different iPhone receives a fresh pairing prompt.

The reset does not cryptographically erase flash or a removed microSD card. Do not use private audio in this EVT.
