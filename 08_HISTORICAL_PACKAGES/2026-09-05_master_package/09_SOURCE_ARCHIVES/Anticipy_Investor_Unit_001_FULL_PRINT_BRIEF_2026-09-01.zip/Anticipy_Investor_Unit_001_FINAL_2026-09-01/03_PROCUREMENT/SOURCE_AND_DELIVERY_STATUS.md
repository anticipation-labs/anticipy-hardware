# Source and delivery status — checked 2026-09-01 PT

| Item | Verified fact | Build decision |
|---|---|---|
| Shell | User correction: no shell is physically present. Corrected CAD imports the exact historical 51 x 22 x 10 mm body and hooked face, exports both as watertight printable STL files, and records 1,424 checks with 0.0 mm3 maximum unintended overlap. | Print two complete black PETG body/face pairs plus the primary screw bands/posts/jig and gauges; use the first pair for destructive fit/drill tests. |
| XIAO boards | User reports boards in hand; exact model/header state is not photographed here. | Use only headerless XIAO nRF52840 Sense; keep one known-good spare. |
| Primary owner2 firmware | Two clean builds are byte-identical, 528,384 bytes, SHA-256 `f246fc79ff9925fb427585e8babf4fe106ea1ad1c32a82b2c4351d3cc55ea5d6`. D0 is active-high. No physical iPhone/hardware test has run here. | Use only with ordered DigiKey low-side circuit; HOLD until QA. |
| Lee-fallback owner2 firmware | Two separate clean builds are byte-identical, 528,384 bytes, SHA-256 `54b12eefb226d886ae374043ad2e5e409f5301956940de8bb13f76d084d14299`. Only source delta makes D0 active-low. | Use only with Lee PID170433 P-channel high-side circuit; never mix; HOLD until QA. |
| Renata ICP501022UPM / 100640 | Official page reports 80 mAh and 24 x 10 x 5.5 mm. Archived manufacturer datasheet reports safety circuit, 40 mA normal/80 mA max charge and states IEC62133 certification. Archived exact-model UN38.3 summary reports T1-T8 passed. | First battery target; local stock remains unconfirmed. |
| SparkFun PRT-13853 / Data Power DTP401525 | Specification reports protected 110 mAh, T<=4.0, W<=15.0, L<=25.0, L2<=25.3 mm, 22 mA standard and 110 mA maximum continuous charge. Matching received-lot UN38.3 and local delivery are unconfirmed. | Conditional Plan B geometry only; both new gauges plus exact identity/docs, no-load, RF, charge and thermal gates are mandatory. |
| Swiss Watch Parts | Renata lists the Vancouver firm as a distribution partner. Public physical stock is unconfirmed. | Call 09:00; buy one exact article only after label/docs, ask for an unpaid same-lot hold of 11. |
| Vancouver Battery / Cadex | Local contact leads only; no evidence either stocks exact pack. | Call and require exact label/photo/docs; buy one and hold 11 only after verification. |
| Lee battery PID160959 / 8834 | Candidates lack adequate exact manufacturer/charge/UN38.3 evidence. PID8834 is not proved equivalent to DTP401525. | Local delivery fallback only; reject unless every battery counter gate passes. |
| Ordered Vybronics VCLP1020B002L | In DigiKey 101304421; tolerance envelope is 10.2 mm diameter x 2.3 mm. | Primary haptic; verify received identity/current and use its exact gauge. |
| Lee coin motor PID10431 | Listing describes 3 V sealed 10 x 2.7 mm at C$4.10. The corrected screw-layout CAD qualifies a conservative 10.2 x 10.2 x 2.7 mm mechanical envelope at the same centre. Search-index stock is not a physical reservation; maker/current/duty remain unverified. | Buy 12 for the all-local path after staff physically holds them; gauge the received body and complete identity/current/duty/system-current/audio/RF tests. |
| Lee barrel PID104281 | Exposed rotating head; no qualified guard in packet. | Not a Unit 001 shipping fallback. |
| Ordered haptic driver | DigiKey 101304421 contains AO3400A, 1N4148W-HF, 100 ohm and 100 kohm parts for the exact D0 circuit. | Primary circuit; verify received packages/pinouts and completed 8 x 4 x 2 mm island. |
| Lee NTR4101P high-side local path | PID170433 NTR4101P P-FET is C$1 each. PID20011 BAS16 is C$2.50 per 5-pack. PID17426 10 kohm 0603 is C$1.25 per 20-pack. Counts can change and are not reserved. | Buy 12 FETs, 3 diode packs and 1 resistor pack for the all-local path. Wire high-side and use only the separate active-low UF2. |
| Lee N-MOSF alternatives | No in-stock Lee SOT-23 N-MOSF found with guaranteed low on-resistance at 2.5–3.3 V. IRLML2502 was out of stock; generic 2N7002 is not an accepted production substitute. | No drop-in active-high local driver is qualified. |
| Lee mechanical parts | PID160266 black Matter3D PETG is C$35. PID6836 M2x10 is listed C$1.20 per 10-pack; online finish, included angle, physical stock and fit are not confirmed. PID6748 M2x8 is listed C$1.50 per 10-pack. | Buy one PETG spool and three PID6836 M2x10 packs. Use PID6748 M2x8 only as a physically validated fallback. Use 2.2 mm preferred/3/32 inch allowed holes, never >2.4 mm, and a 90-degree countersink. |
| KMS tooling | 110 Woolridge St, Coquitlam; Tue 08:00–18:00. DB-SP332 3/32 inch HSS bit is listed C$3.99 and DIM-202C12 1/2-inch 90-degree countersink is listed C$8.99; physical Coquitlam stock is unconfirmed. | Call for a physical hold and buy one of each only if the hardware guy does not confirm equivalents in hand. Never substitute an 82-degree countersink. |
| Lee technical hold | A Lee hold email was sent for the local build items. | Call before travel; record staff name, physical count, hold expiry and pickup time. An email is not stock confirmation. |
| Amazon assembly consumables | User reports the assembly consumables are already due Tuesday. | Already bought; do not rebuy. Verify contents on arrival. |
| Memory Express CSO006089271 | Pickup-ready notice for ten cards/cables; existing evidence says C$386.74 is due at pickup. | Not a Unit 001 dependency. Do not collect for this build without separate authorization. |
| DigiKey 101304421 | Shipment email dated Aug 29 with FedEx 539111734891. Includes XIAOs, Vybronics motors and exact driver parts. Tracker did not resolve in the last check. | Already bought; check physical delivery before local fallback purchase. ETA is unconfirmed. |
| DigiKey MyoWare 101311973 | Separate shipment; not Anticipy inventory. | Ignore for this build. |
| TME 35388887 | Shipment confirmation for Raytac modules used by later custom PCB. | Not a Wednesday XIAO dependency. |

Live stock and tracking change. A call with staff name, physical count, exact
MPN photo, hold expiry, and pickup time is the required reservation evidence.
For the Lee motor/P-FET fallback on Renata 100640, the release gate is combined
board-plus-motor draw <=160 mA peak and <=80 mA continuous, with no reset or
heat; a motor-only current measurement is insufficient.
