# Put the Tuesday app on an iPhone

You need a Mac with Xcode, an Apple ID, an iPhone running iOS 16 or later, and a USB cable.

1. Open `AnticipyTuesday.xcodeproj` in Xcode.
2. Click the blue project icon, then the **AnticipyTuesday** target, then **Signing & Capabilities**.
3. Turn on **Automatically manage signing** and choose your Apple development team.
4. If Xcode says the bundle identifier is unavailable, replace `ai.anticipy.tuesday` with a unique value such as `ai.anticipy.tuesday.omar`.
5. Plug in and unlock the iPhone. Tap **Trust** if asked.
6. Choose that iPhone in Xcode's device menu and press the triangular **Run** button.
7. If iOS blocks the developer app, follow the on-screen path to enable Developer Mode, restart the phone, then press Run again.
8. Open Anticipy, allow Bluetooth, choose the pendant beside you, and accept the Bluetooth pairing prompt.

The app remembers that pendant and attempts to reconnect later. **Choose a different pendant** removes the app's saved selection; the firmware factory-reset gesture clears the pendant's saved bond.

## What the screen means

- **Live** counts raw Opus packets arriving now.
- **Recovered** counts raw Opus packets extracted from the offline microSD backlog.
- **Recover offline audio** requests a resumable backfill.
- **Test vibration** verifies the command path to the pendant.

These raw packets are saved for engineering proof. This app has no decoder, playback, transcription, cloud upload, account, or customer privacy controls.

## Distribution truth

Direct Xcode install is the only predictable Tuesday path. A free Apple ID build may expire after about seven days and has device limits. A paid Apple Developer account normally gives longer-lived development provisioning, but each iPhone still has to be registered/provisioned. External TestFlight requires an App Store Connect record, archive upload, compliance metadata, and Apple's first-build beta review, so it cannot be promised by Tuesday. Internal TestFlight is only for App Store Connect team members and still requires a valid archive and signing setup.
