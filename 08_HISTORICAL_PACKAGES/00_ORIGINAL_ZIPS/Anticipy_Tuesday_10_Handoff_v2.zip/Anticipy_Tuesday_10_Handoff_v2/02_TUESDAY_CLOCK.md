# THE TUESDAY CLOCK

## Saturday

1. Builder accepts the job and fixed quote.
2. Checkout verifies Tuesday arrival for every shipped part.
3. Reserve local microSD cards.
4. Start one polycarbonate body immediately.

## Sunday

1. Finish and inspect unit 1 shell.
2. Prepare electronics harnesses, memory cards and aluminum cutting nest.
3. Do not multiply the shell until the actual battery and board have been caliper-checked.

## Monday morning

1. Receive parts and inspect every pouch cell.
2. Flash and bench-test electronics for unit 1.
3. Build and close unit 1.
4. Prove iPhone pairing, live audio, offline storage, backfill and factory reset.

## Monday afternoon and night

1. If unit 1 passes, print/cut/assemble the remaining 11 in parallel.
2. Number every unit and record its test result.
3. Reject bad cosmetics, hot cells, weak radio, failed SD cards and rattles.

## Tuesday

1. Select the best 10.
2. Clean, charge and repeat the short functional test.
3. Install software on the demonstration iPhone.
4. Pickup in Vancouver/Burnaby.

## The two hard blockers

- No verified Tuesday source yet for 12 exact protected batteries.
- No signed, investor-installable iPhone app exists yet. A direct Xcode install on one local demo phone is the current Tuesday-safe path.

