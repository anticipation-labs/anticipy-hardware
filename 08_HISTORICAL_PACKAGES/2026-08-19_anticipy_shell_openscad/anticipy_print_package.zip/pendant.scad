// =====================================================================
// Anticipy pendant shell v3 — matches the anticipy.ai production pendant
//
// Shape: PILL. Stadium outline (fully semicircular top end), soft-round
// bottom end, deep R5 edge roll all around (minkowski), through-hole
// bail at the top with chamfered rims, countersunk mic/LED dot on the
// front, flush USB-C nose-through port in the bottom, "Anticipy"
// debossed on the back reading top-to-bottom.
//
// Electronics (verified: Seeed STEP/DXF/KiCad + photos):
//   XIAO nRF52840 Sense — PCB 20.955 x 17.78 x 1.24; USB-C 8.94w x 3.21h
//   overhangs edge 1.53, plug axis 1.60 above PCB top; underside flat;
//   headers: insulator 2.54 + posts 6.0 below PCB.
//   Mic aperture 1.52 from antenna edge, 3.37 from 5V-row long edge.
//   BLL 752042 LiPo — 8.0 x 20.5 x 43.0 max as-shipped.
//
// Frame: X width, Y height (+Y bail, -Y USB), Z depth, +Z FRONT.
// Parting plane Z=0; halves print parting-face-down; no supports.
// Verification-driven fixes baked in (adversarial review round 1):
//   - flush port (no overmold pocket => no seating/blend failures)
//   - every cavity is intersected with the inner envelope (pebble(WALL_MIN))
//     so a thin wall or breakout is geometrically impossible
//   - bail hole replaces side tunnel; chamfered rims (no feather edges)
//   - registration: bail rod + USB plug jig + 2 filament dowels
// =====================================================================

VARIANT = 1;        // -D VARIANT=n
HALF = "assembly";  // "front"|"back"|"assembly"|"section"|"open_back"|"open_front"|"backtext"|"text"

$fa = 3; $fs = 0.3;
EPS = 0.01;
BIG = 400;

// ------------------------- electronics facts -------------------------
BAT_W = 20.5;  BAT_L = 43.0;  BAT_T = 8.0;
BRD_L = 20.955;  BRD_W = 17.78;  PCB_T = 1.24;
BRD_T_TOP  = 4.7;           // PCB 1.24 + USB-C 3.21 + 0.25
BRD_T_UNDER_CLIPPED = 3.4;
BRD_T_UNDER_PINS    = 9.4;
USB_MOUTH_OVERHANG  = 1.53;
USB_AXIS_ABOVE_PCB_TOP = 1.60;
USB_SHELL_W = 8.94;  USB_SHELL_H = 3.21;

// ------------------------- variant table -----------------------------
CLR      = (VARIANT == 2) ? 0.85 : 0.5;
DEPTH_PAD= (VARIANT == 2) ? 0.8  : 0.0;
PINS_CLIPPED = (VARIANT != 3);
DOWEL_D  = (VARIANT == 4) ? 2.05 : 1.9;
CUT_PAD  = (VARIANT == 4) ? 0.4  : 0.0;

// ------------------------- walls & bays ------------------------------
WALL = 2.0;                    // 5 x 0.4 perimeters
WALL_MIN = 1.4;                // hard floor enforced by envelope clipping

BAT_BAY_W = BAT_W + 2*CLR;                 // 21.5 (V1)
BAT_BAY_L = BAT_L + 2.2 + CLR;             // 45.7: taped end + PCM
BAT_BAY_T = BAT_T + 0.8 + DEPTH_PAD;       // 8.8 hard depth (+foam preload)

BRD_UNDER = PINS_CLIPPED ? BRD_T_UNDER_CLIPPED : BRD_T_UNDER_PINS;
BRD_BAY_L = BRD_L + USB_MOUTH_OVERHANG + 0.8 + CLR;
BRD_BAY_W = BRD_W + 1.4 + 2*CLR;
BRD_BAY_T = BRD_T_TOP + BRD_UNDER + 0.6 + DEPTH_PAD;

SEP_T   = PINS_CLIPPED ? 0 : 1.0;
GAP_BB  = 1.5 + SEP_T;

// ------------------------- envelope ----------------------------------
FRONT_GAP = 0.8;
D_INT = FRONT_GAP + BRD_BAY_T + GAP_BB + BAT_BAY_T;
D     = D_INT + 2*WALL;

BAIL_D    = 6.4 + CUT_PAD;     // through-hole for jump ring / 3mm chain
BAIL_TOP_WALL = 4.8;           // material above the hole

R_ROLL = 5.0;                  // edge roll radius (max per fit analysis)
R_BOT  = 6.0;   // max bottom roundness that passes the fit proofs (8.5+ fails)

// heights stack up from the bottom
PORT_SHELF = 1.53;             // board USB edge sits this far above outer bottom
Y_STACK = PORT_SHELF + BRD_L;  // top of board region (informative)
BAT_LIFT = 2.6;                // battery bay start above outer bottom
BAIL_ZONE = BAIL_D + BAIL_TOP_WALL + 1.7;   // hole + top wall + gap to battery
H = BAT_LIFT + BAT_BAY_L + BAIL_ZONE;

W = BAT_BAY_W + 2*WALL + 1.0;  // 26.5 (V1)

// ------------------------- positions ---------------------------------
Y_BOT = -H/2;                              // outer bottom apex
BRD_Y0 = Y_BOT + PORT_SHELF;               // PCB USB edge (receptacle face flush)
BAT_Y0 = Y_BOT + BAT_LIFT;
BAT_Y1 = BAT_Y0 + BAT_BAY_L;

BRD_ZTOP = D/2 - WALL - FRONT_GAP;
BRD_ZPCB_TOP = BRD_ZTOP - (BRD_T_TOP - PCB_T);
BAT_ZF   = BRD_ZTOP - BRD_BAY_T - GAP_BB;

BAIL_Y = H/2 - BAIL_TOP_WALL - BAIL_D/2;
DOWEL_X = 6.9;

USB_HOLE_W = USB_SHELL_W + 0.75 + CUT_PAD;   // 9.69 (V1)
USB_HOLE_H = USB_SHELL_H + 0.75 + CUT_PAD;   // 3.96
USB_Z = BRD_ZPCB_TOP + USB_AXIS_ABOVE_PCB_TOP;

MIC_X = -(BRD_W/2 - 3.37);
MIC_Y = BRD_Y0 + BRD_L - 1.52;

// ------------------------- sanity checks -----------------------------
assert(BAT_Y1 <= BAIL_Y - BAIL_D/2 - 1.5, "battery collides with bail");
assert(BAT_ZF - BAT_BAY_T >= -D/2 + WALL - EPS, "battery bay vs back wall");
assert(DOWEL_X - DOWEL_D/2 - BAIL_D/2 >= 2.2, "dowel too close to bail");
echo(str("VARIANT=",VARIANT," W=",W," H=",H," D=",D,
  " | BAT bay ",BAT_BAY_W,"x",BAT_BAY_L,"x",BAT_BAY_T," floor z=",BAT_ZF-BAT_BAY_T,
  " y ",BAT_Y0,"..",BAT_Y1,
  " | BRD bay ",BRD_BAY_W,"x",BRD_BAY_L,"x",BRD_BAY_T," BRD_Y0=",BRD_Y0,
  " BRD_ZTOP=",BRD_ZTOP," | USB ",USB_HOLE_W,"x",USB_HOLE_H," z=",USB_Z,
  " | BAIL y=",BAIL_Y," d=",BAIL_D," | MIC (",MIC_X,",",MIC_Y,")",
  " | DOWEL x=+-",DOWEL_X," y=",BAIL_Y," d=",DOWEL_D));

// ------------------------- pill body ---------------------------------
// 2D core outline (already inset by r): top full-round, bottom R_BOT.
module outline2d(r) {
    hull() {
        translate([0, H/2 - W/2]) circle(W/2 - r);                    // top semicircle
        for (s=[-1,1])
            translate([s*(W/2 - R_BOT), -H/2 + R_BOT]) circle(R_BOT - r); // bottom corners
    }
}
module pebble(d = 0) {
    // exact parallel offset: same 2D core, sphere radius R_ROLL-d
    minkowski() {
        translate([0,0,-(D/2 - R_ROLL)])
            linear_extrude(2*(D/2 - R_ROLL)) outline2d(R_ROLL);
        sphere(R_ROLL - d);
    }
}

module rbox(s, r) {
    hull() for (x=[r, s[0]-r], y=[r, s[1]-r], z=[r, s[2]-r])
        translate([x,y,z]) sphere(r);
}

// ------------------------- cavity ------------------------------------
module cavity_raw() {
    // board bay (front, bottom): floor exactly at the PCB's USB edge — the
    // USB nose below it passes through usb_hole() only. Opens through z=0.
    translate([-BRD_BAY_W/2, BRD_Y0 - 0.05, -0.9])
        rbox([BRD_BAY_W, BRD_BAY_L, BRD_ZTOP + FRONT_GAP + 0.4 + 0.9], 0.9);
    // battery bay + foam gap — front face at z=+0.4
    translate([-BAT_BAY_W/2, BAT_Y0 - 0.4, BAT_ZF - BAT_BAY_T - 0.15])
        rbox([BAT_BAY_W, BAT_BAY_L + 0.4, 0.4 - (BAT_ZF - BAT_BAY_T) + 0.15], 0.9);
    // wire-fold pocket at the bottom
    translate([-BAT_BAY_W/2, Y_BOT + 1.7, BAT_ZF - BAT_BAY_T - 0.3])
        rbox([BAT_BAY_W, 11, BAT_BAY_T + GAP_BB + 1.5], 1.2);
}
module cavity() {
    // GUARANTEE: no cavity may come closer than WALL_MIN to the outside.
    intersection() { cavity_raw(); pebble(WALL_MIN); }
}
module separator() {
    if (SEP_T > 0)
        intersection() {
            translate([-BAT_BAY_W/2 - 0.5, BRD_Y0 + 1.2, BAT_ZF + 0.1])
                cube([BAT_BAY_W + 1.0, BRD_BAY_L, SEP_T]);
            pebble(WALL_MIN + 0.2);
        }
}

// ------------------------- features ----------------------------------
module bail_hole() {
    // through-hole + generous 1.6mm 45-deg chamfers on both rims
    translate([0, BAIL_Y, 0]) {
        cylinder(h = D + 4, d = BAIL_D, center = true);
        // rim chamfers: s=-1 back face, s=+1 front face (rotate flips the
        // cone so the wide end always sits AT the face — verified in mesh)
        for (s=[-1,1]) {
            zf = bail_face_z();
            translate([0, 0, s*zf]) rotate([90+s*90,0,0])
                translate([0,0,-0.01])
                cylinder(h = 1.62, d1 = BAIL_D + 3.2, d2 = BAIL_D);
        }
    }
}
function bail_face_z() = bail_face_z_calc();
function bail_face_z_calc() =
    // depth of the outer surface at the bail centerline (x=0, y=BAIL_Y):
    // inside the top arc's full-thickness zone the face is flat at D/2
    D/2;

module usb_hole() {
    // flush nose-through port: rounded-rect for the USB-C shell + clearance,
    // outside chamfer, plus a 0.45mm "landing scoop" facet so the seated
    // plug's overmold (which stops 0.45 in front of the receptacle face)
    // never collides with the rolled bottom edge.
    r = 0.9;
    translate([0, Y_BOT + 3, USB_Z]) rotate([90,0,0]) {
        hull() for (sx=[-1,1], sz=[-1,1])
            translate([sx*(USB_HOLE_W/2 - r), sz*(USB_HOLE_H/2 - r), 0])
                cylinder(h = 12, r = r, center = true);
        // lead-in chamfer at the outside face (local +z maps to global -y =
        // outward; the outer apex plane sits at local z=+3, so the flare
        // must live in z [1.4, 3.05] widening OUTWARD — mesh-verified)
        hull() for (sx=[-1,1], sz=[-1,1])
            translate([sx*(USB_HOLE_W/2 - r), sz*(USB_HOLE_H/2 - r), 3 - 1.6])
                cylinder(h = 1.65, r1 = r, r2 = r + 1.1);
    }
    // landing scoop: everything below y = Y_BOT + 0.45 inside the overmold
    // footprint (spec max 12.35 x 6.5 + clearance) is cleared
    intersection() {
        translate([-20, Y_BOT - 5, -20]) cube([40, 5 + 0.45, 40]);
        translate([0, Y_BOT + 3, USB_Z]) rotate([90,0,0])
            hull() for (sx=[-1,1], sz=[-1,1])
                translate([sx*(13.4/2 - 2), sz*(7.4/2 - 2), 0])
                    cylinder(h = 16.2, r = 2, center = true);
    }
}

module mic_port() {
    // countersunk dot like the production pendant's LED
    translate([MIC_X, MIC_Y, 0]) {
        translate([0,0, D/2 - WALL - 1]) cylinder(h = WALL + 2, d = 1.8);
        translate([0,0, D/2 - 0.85]) cylinder(h = 2, d1 = 1.8, d2 = 3.6);
    }
}

TEXT_DEPTH = 0.5;   // deboss depth; keeps >=1.35 wall over the battery bay
module text_back() {
    intersection() {
        translate([0, -1.5, -D/2 - 1])
            mirror([1,0,0]) rotate([0,0,90])
            linear_extrude(D, convexity = 10)
                text("Anticipy", size = 6.0, font = "Avenir Next:style=Medium",
                     halign = "center", valign = "center", spacing = 1.08);
        difference() { pebble(-0.02); pebble(TEXT_DEPTH); }
        translate([-BIG/2, -BIG/2, -BIG]) cube(BIG);
    }
}

module dowel_holes() {
    for (s=[-1,1])
        translate([s*DOWEL_X, BAIL_Y, -3]) cylinder(h = 6, d = DOWEL_D);
}

// ------------------------- shell -------------------------------------
module shell_solid() {
    union() {
        difference() {
            pebble(0);
            cavity();
            bail_hole();
            usb_hole();
            mic_port();
            text_back();
            dowel_holes();
        }
        separator();
    }
}
module half_back()  { intersection() { shell_solid(); translate([-BIG/2,-BIG/2,-BIG]) cube(BIG); } }
module half_front() { intersection() { shell_solid(); translate([-BIG/2,-BIG/2,0])    cube(BIG); } }

// ------------------------- dummies (viz) ------------------------------
module dummies() {
    color("silver", 0.65)
        translate([-BAT_W/2, BAT_Y0 + 0.4, BAT_ZF - 0.4 - BAT_T]) cube([BAT_W, BAT_L, BAT_T]);
    color("green", 0.75)
        translate([-BRD_W/2, BRD_Y0, BRD_ZPCB_TOP - PCB_T]) cube([BRD_W, BRD_L, PCB_T]);
    color("dimgray", 0.85)
        translate([-USB_SHELL_W/2, BRD_Y0 - USB_MOUTH_OVERHANG, BRD_ZPCB_TOP])
            cube([USB_SHELL_W, 7.3, USB_SHELL_H]);
}

// ------------------------- top level ---------------------------------
// ---- machine-checkable fit tests: each must export an EMPTY mesh ----
if (HALF == "test_batfit")
    // battery max envelope (+0.2 wiggle, real pouch corner rounding ~2mm)
    difference() {
        translate([-(BAT_W+0.2)/2, BAT_Y0 + 0.3, BAT_ZF - 0.1 - (BAT_T+0.2)])
            rbox([BAT_W+0.2, BAT_L+0.4, BAT_T+0.2], 2.0);
        cavity();
    }
else if (HALF == "test_brdfit")
    // board: PCB (real R1.9 corners) + underside block + USB nose, seated
    difference() {
        union() {
            translate([0, 0, BRD_ZPCB_TOP - PCB_T])
                linear_extrude(PCB_T) hull()
                    for (sx=[-1,1], sy=[0,1])
                        translate([sx*(BRD_W/2-1.9), BRD_Y0+1.9 + sy*(BRD_L-3.8)])
                            circle(1.9);
            translate([0, 0, BRD_ZPCB_TOP - BRD_UNDER])
                linear_extrude(BRD_UNDER - PCB_T) hull()
                    for (sx=[-1,1], sy=[0,1])
                        translate([sx*(BRD_W/2-1.9), BRD_Y0+2.1 + sy*(BRD_L-4.2)])
                            circle(1.9);
            translate([-USB_SHELL_W/2, BRD_Y0 - USB_MOUTH_OVERHANG, BRD_ZPCB_TOP])
                cube([USB_SHELL_W, 7.3, USB_SHELL_H]);
        }
        cavity();
        usb_hole();
    }
else if (HALF == "test_bailclear")
    // chain path must never reach the electronics cavity
    intersection() {
        translate([0, BAIL_Y, 0]) cylinder(h = D + 4, d = BAIL_D + 3.2, center = true);
        cavity_raw();
    }
else if (HALF == "test_dowelclear")
    intersection() { dowel_holes(); union() { cavity_raw(); bail_hole(); } }
else if (HALF == "text")            text_back();
else if (HALF == "front")      half_front();
else if (HALF == "back")       rotate([180,0,0]) half_back();
else if (HALF == "open_back")  { half_back(); dummies(); }
else if (HALF == "open_front") { half_front(); dummies(); }
else if (HALF == "backtext")   { half_back(); color("red") text_back(); }
else if (HALF == "section") {
    intersection() {
        union() { half_front(); half_back(); }
        translate([-BIG,-BIG/2,-BIG/2]) cube(BIG);
    }
    dummies();
}
else { half_front(); half_back(); %dummies(); }
