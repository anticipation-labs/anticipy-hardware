# Tuesday software verification report

Status: **software build passes; physical release does not yet pass**.

## Completed here

| Check | Result |
|---|---|
| Clean nRF52840 firmware compile | Pass |
| UF2 produced | Pass — 587,264 bytes |
| UF2 SHA-256 | `74f3c7f25b9e51660d627e193a6efbd500a66e85ede9c3d4de3dffa4caa61867` |
| Firmware identity | Pass — `0.9.1-evt` present in ELF |
| Host protocol/storage checks | Pass |
| Factory-reset source check | Pass — boot-only 8-second hold, unpair, storage clear, reboot |
| Info.plist parse | Pass |
| Xcode project reference/static check | Pass |
| iOS compile on macOS/Xcode | Not run — Xcode unavailable here |
| Real XIAO + iPhone test | Not run — hardware unavailable here |

Firmware footprint: 293,396 bytes flash / 168,924 bytes RAM.

## Required before one unit leaves

Write the unit serial number beside each result.

| Test | Pass condition | Result |
|---|---|---|
| Flash | UF2 copies and pendant reboots | ☐ |
| Fresh pair | New iPhone receives pairing prompt and connects | ☐ |
| Live audio transport | Live packet counter increases continuously for 10 minutes | ☐ |
| Offline record | Turn iPhone Bluetooth off, speak for 10 minutes, reconnect | ☐ |
| Backfill | Recovered packet counter increases and progress completes | ☐ |
| Resume | Interrupt one backfill, reconnect, and complete without app error | ☐ |
| Haptic | Test vibration works 10/10 times without reset | ☐ |
| Button | Intended button events appear 10/10 times | ☐ |
| Locked iPhone | Live counter resumes after a 30-minute locked/background test | ☐ |
| Runtime | Unit survives the intended all-day profile; record measured hours | ☐ |
| Factory reset | 8-second boot hold clears bond/audio and a second iPhone pairs | ☐ |

## Release blockers that remain

- Audio is raw Opus packets only; there is no in-app decoding, playback, transcription, or upload.
- Offline files are plaintext and pairing is encrypted but not MITM-authenticated.
- No measured 16-hour runtime, RF range, microphone quality, locked-iPhone reliability, thermal, drop, or ten-unit repeatability result exists yet.

Do not represent an unchecked box as tested. If the live counter increases but the audio has not been decoded on a separate engineering tool, that proves transport, not intelligible recording quality.
