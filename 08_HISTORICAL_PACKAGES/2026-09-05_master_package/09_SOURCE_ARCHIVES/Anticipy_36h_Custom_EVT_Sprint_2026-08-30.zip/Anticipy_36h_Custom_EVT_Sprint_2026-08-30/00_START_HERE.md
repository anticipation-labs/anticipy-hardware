# Anticipy custom-EVT execution sprint

Checkpoint time: Sunday 2026-08-30 08:43 PDT  
Requested deadline: Monday 2026-08-31 20:43 PDT  
Product route: custom PCB, custom polycarbonate structure, custom aluminum faces.

## The decision in one sentence

A tested, working custom Anticipy pendant cannot be in hand by the requested
36-hour deadline from the current design state. The honest 36-hour target is a
reviewed digital manufacturing release and booked fabrication capacity; the
physical first article follows after board fabrication, assembly, firmware
bring-up, and enclosure integration.

The 36-hour window begins on Sunday and contains only one normal business day.
It does not contain enough elapsed process time to manufacture a four-layer
board, source and reflow its components, debug revision-one hardware, fabricate
the enclosure, install the battery and motor, and test the sealed product.

## What the finished object is

The first successful Anticipy EVT is one hand-built, serial-numbered pendant:

| Element | Final result |
|---|---|
| Exterior | Rounded capsule, no larger than 51 x 21 x 11 mm |
| Electronics | 45.8 x 18.0 x 0.80 mm four-layer custom PCBA |
| Radio/processor | Raytac nRF52840 BLE module |
| Power | nPM1300 charger/power system and qualified protected LiPo with NTC |
| Audio | Two PDM microphones and verified acoustic ports |
| Storage | Soldered serial NAND with tested ECC, bad-block, and recovery firmware |
| Interaction | Button, red/blue light pipe, haptic motor, USB-C |
| Structure | Polycarbonate centre and radio nose |
| Faces | 0.60 mm brushed 5052-H32 aluminum, front and rear |
| Release evidence | Programming record, electrical test, audio test, RF test, charge/thermal test, runtime test, and serial-numbered build record |

## What exists now

| Item | Status |
|---|---|
| Editable KiCad schematic and board | Built |
| Board outline and placement | Built: 45.8 x 18.0 mm |
| Four-layer rules and draft BOM | Built |
| Verified source connectivity | Built: 70 references, 223 connected pins |
| Geometric PCB DRC | Pass: zero violations on clean master |
| Complete routing | Not built: 176 connections remain on clean master |
| Exact production battery | Not selected |
| Released Gerbers, drills, BOM, CPL | Not built; intentionally blocked |
| Complete PCBA STEP | Not built |
| Final enclosure STEP/3MF/DXF | Not built |
| Production firmware binary | Not built |
| Physical custom PCBA or pendant | None |

The complete engineering checkpoint is in:

`Engineering_Source/Anticipy_R0B_Engineer_Handoff_2026-08-29.zip`

Do not upload the current board to a factory as a production order. The master
board is intentionally unrouted and the battery is a placeholder.

## The fastest credible pipeline

### Phase 1 - engineering release

One senior owner must simultaneously control PCB, battery, firmware, and
mechanical interfaces. The strongest local first call is MistyWest for an
urgent, paid full-stack sprint. A senior KiCad contractor can be added only if
MistyWest cannot start immediately.

Required output:

- zero unrouted connections;
- zero serious ERC/DRC errors;
- reviewed nPM1300 power layout;
- fabricator-approved stack-up and USB geometry;
- exact battery selected and qualified;
- released Gerbers, drills, IPC-356, BOM, CPL, drawings, STEP, and checksums;
- factory-test firmware and programming instructions.

### Phase 2 - two first PCBAs

CCI Canadian Circuits receives the released electronics package. It fabricates
the blank PCBs, orders/kits the BOM, stencils and reflows two first PCBAs, then
performs inspection. The remaining ten stay on hold.

CCI publicly advertises 24-hour rush PCB fabrication and a rapid prototype PCBA
service. Those are capabilities, not a written promise that component sourcing,
assembly, and delivery of this design will all finish in 24 hours. Obtain a
written schedule before payment.

### Phase 3 - enclosure

After the battery and complete PCBA STEP are frozen, the mechanical engineer
releases:

- polycarbonate centre STEP and 3MF;
- front and rear aluminum DXF/vector PDF;
- light-pipe, button, USB, acoustic, adhesive, insulation, and antenna details;
- dimensioned assembly drawing and exploded STEP.

MakerLabs can quote same-day aluminum cutting subject to availability. Its
published turnaround clock is in business days. It supplies the aluminum sheet;
the customer does not send raw metal unless specifically agreed.

### Phase 4 - bring-up and final integration

The PCB/firmware engineer powers and programs FA-001 and FA-002 before battery
or motor installation. After electrical bring-up, a local integration technician
installs the approved battery, motor, mesh, light pipe, insulation, PCBA, and
faces. The technician seals one unit and runs the complete test plan. Only a
written pass releases the rest.

## What happens during the requested 36 hours

| Time | Owner | Required result |
|---|---|---|
| Sunday morning | Anticipy | Send the full source ZIP to MistyWest and a senior KiCad engineer; request immediate paid sprint and named lead |
| Sunday morning | Anticipy | Send capability-only RFQ to CCI; do not send an order or call the current files released |
| Sunday morning | Anticipy | Send capability-only metal RFQ to MakerLabs; state that final DXFs follow after mechanical freeze |
| Sunday | PCB/battery lead | Freeze an exact protected three-wire LiPo with 10k NTC, drawing/STEP, polarity, protection, stock, and compliance documents |
| Sunday-Monday | PCB lead | Consolidate routing, run ERC/DRC, peer-review power/RF/USB/storage, and generate PCBA STEP |
| Monday | CCI + PCB lead | Return and approve 0.80 mm stack-up, USB impedance geometry, capability/DFM, material stock, and written dates |
| Monday | Firmware lead | Produce factory-test firmware, binary hash, flash/verify commands, and first-article test limits |
| Monday | Mechanical lead | Start enclosure only from selected battery and reviewed PCBA STEP |
| Monday 20:43 | Project lead | Either issue a checksummed engineering release or record a no-go with exact blockers; never force an unsafe release |

## Earliest physical outcome

No physical completion date should be promised until CCI and the engineering
lead confirm parts stock and written dates. A very aggressive revision-one
result is one or two custom EVT units within roughly five business days after a
valid release. Seven to fourteen calendar days is the more honest planning
range. A revision-one failure triggers PCB rework or a second board spin.

## Non-negotiable release rules

1. No fabrication while PCB connectivity is incomplete.
2. No battery purchase from dimensions alone.
3. No enclosure freeze before the exact battery and full PCBA STEP exist.
4. No remaining-ten assembly before both first PCBAs pass bring-up.
5. No sealed-product claim before audio, BLE, charging, temperature, runtime,
   storage recovery, button, light, haptic, and mechanical tests pass.
6. No aluminum in the radio keepout/nose.

## Immediate calls

1. MistyWest: 604-292-7036, `contact@mistywest.com`. Ask for a named senior
   hardware lead, firmware lead, mechanical lead, start time, scope, hourly cap,
   and first-article support.
2. CCI Canadian Circuits: 604-599-8600, `sales@canadiancircuits.com`. Ask whether
   it can reserve rush four-layer fabrication and two-board prototype assembly,
   and whether all critical MPNs can be sourced or must be consigned.
3. MakerLabs: 778-984-7299, `hello@makerlabs.com`. Ask whether 0.60 mm
   5052-H32 stock, fine brushing, deburring, vector cutting, and same-day Monday
   capacity are available.
4. Enigma: 604-420-3313, `boards@enigmacorp.com`. Hold as the local bare-board
   backup; it does not replace component assembly and final integration.

The user must approve quotes, pay vendors, deliver/receive physical parts, and
name the person who can perform local integration and testing. The engineering
team must own the files and physical validation.

