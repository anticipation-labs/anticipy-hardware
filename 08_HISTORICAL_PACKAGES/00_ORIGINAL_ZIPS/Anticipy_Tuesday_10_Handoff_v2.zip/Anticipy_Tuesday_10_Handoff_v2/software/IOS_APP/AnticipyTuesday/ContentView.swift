import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var model: PendantViewModel

    var body: some View {
        ZStack {
            Color(red: 0.045, green: 0.048, blue: 0.052).ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    privacyWarning

                    if model.selectedID == nil {
                        devicePicker
                    } else {
                        pendantCard
                        signalCard
                        controls
                    }

                    if let error = model.errorMessage {
                        Text(error)
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }

                    Text("Tuesday EVT • Raw Opus transport receiver")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("ANTICIPY")
                .font(.caption.weight(.semibold))
                .tracking(4)
                .foregroundStyle(.secondary)
            Text("Founder Setup")
                .font(.system(size: 36, weight: .medium, design: .rounded))
            HStack(spacing: 8) {
                Circle()
                    .fill(model.ready ? Color.green : (model.connected ? Color.yellow : Color.gray))
                    .frame(width: 9, height: 9)
                Text(model.status)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var privacyWarning: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("Private-audio warning")
                .font(.subheadline.weight(.semibold))
            Text("This Tuesday EVT stores offline recordings in plaintext. Use only synthetic or explicitly non-sensitive test audio.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.orange.opacity(0.35)))
    }

    private var devicePicker: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Choose the pendant beside you")
                    .font(.headline)
                Spacer()
                Button("Refresh") { model.refresh() }
                    .font(.subheadline)
            }

            if model.devices.isEmpty {
                ProgressView("Looking for Anticipy Founder")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 18)
            } else {
                ForEach(model.devices) { pendant in
                    Button {
                        model.choose(pendant)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(pendant.name).font(.body.weight(.medium))
                                Text(String(pendant.id.uuidString.suffix(6)))
                                    .font(.caption.monospaced())
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text("\(pendant.rssi) dBm")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                            Image(systemName: "chevron.right")
                        }
                        .padding(16)
                        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var pendantCard: some View {
        HStack(spacing: 16) {
            RoundedRectangle(cornerRadius: 18)
                .fill(LinearGradient(colors: [.white.opacity(0.9), .gray], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 42, height: 92)
                .overlay(Circle().stroke(Color.black.opacity(0.5), lineWidth: 2).frame(width: 9, height: 9).offset(y: -30))
            VStack(alignment: .leading, spacing: 5) {
                Text(model.selectedName).font(.headline)
                Text(model.connected ? "Connected" : "Reconnecting")
                    .font(.subheadline)
                    .foregroundStyle(model.connected ? Color.green : Color.yellow)
                if let id = model.selectedID {
                    Text(String(id.uuidString.suffix(6)))
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
        }
        .padding(18)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 20))
    }

    private var signalCard: some View {
        VStack(spacing: 16) {
            HStack {
                metric(title: "Live", value: model.liveDuration, detail: "\(model.liveFrames) packets")
                Divider().frame(height: 54)
                metric(title: "Recovered", value: model.backlogDuration, detail: "\(model.backlogFrames) packets")
            }
            if model.backlogTotal > 0 {
                VStack(alignment: .leading, spacing: 7) {
                    ProgressView(value: model.backlogProgress)
                    Text("Backfill \(model.backlogCommitted) / \(model.backlogTotal) bytes")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(18)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 20))
    }

    private func metric(title: String, value: String, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title2.monospacedDigit().weight(.medium))
            Text(detail).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var controls: some View {
        VStack(spacing: 10) {
            Button("Recover offline audio") { model.requestBackfill() }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(!model.connected)
            Button("Test vibration") { model.testHaptic() }
                .buttonStyle(SecondaryButtonStyle())
                .disabled(!model.connected)
            Button("Choose a different pendant") { model.forgetPendant() }
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(.top, 4)
        }
    }
}

private struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .foregroundStyle(.black)
            .background(Color.white.opacity(configuration.isPressed ? 0.75 : 0.95), in: Capsule())
    }
}

private struct SecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.medium))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 13)
            .foregroundStyle(.white)
            .background(Color.white.opacity(configuration.isPressed ? 0.05 : 0.1), in: Capsule())
            .overlay(Capsule().stroke(Color.white.opacity(0.18)))
    }
}
