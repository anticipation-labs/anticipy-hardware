# Ready-to-send Anticipy sprint messages

These messages request capability and immediate engineering work. They do not
authorize fabrication from the current files.

## MistyWest - prime engineering owner

To: `contact@mistywest.com`  
Subject: `Emergency custom wearable EVT sprint - Anticipy - Vancouver`

Hi,

We need a named senior team to take immediate ownership of a compact custom
wearable EVT: PCB completion and review, battery selection, factory-test
firmware, enclosure CAD, first-board bring-up, and local final integration.

The attached package is a real editable KiCad engineering checkpoint, not a
fabrication release. The board is 45.8 x 18.0 mm, four layers, and must fit a
finished 51 x 21 x 11 mm pendant. It uses an nRF52840 Raytac module, nPM1300,
dual PDM microphones, soldered NAND, accelerometer, USB-C, LED, button, and
haptic driver. The clean board currently has zero geometric DRC violations but
176 unrouted connections. The exact protected three-wire LiPo, production
firmware, complete PCBA STEP, and enclosure remain open.

We are not asking you to pretend the current files are manufacturable. We need
an immediate paid engineering sprint and an honest first-article schedule.

Please confirm today:

1. The named senior hardware, firmware, and mechanical leads.
2. Earliest start time and whether work can begin immediately.
3. Whether you can finish and peer-review the PCB, select the battery, create
   factory-test firmware, support CCI DFM, and own first-board bring-up.
4. Whether you can produce the complete PCBA STEP and final enclosure package.
5. Your 36-hour engineering deliverables, earliest physical first-article date,
   hourly rates, rush premium, and approval cap.

The goal is one or two working custom EVT units first, then a held batch of ten.

Thank you.

Attachment: `Anticipy_R0B_Engineer_Handoff_2026-08-29.zip`

## CCI Canadian Circuits - rush PCB/PCBA capability hold

To: `sales@canadiancircuits.com`  
Subject: `RUSH capability hold - two first-article Anticipy PCBAs`

Hi,

We are completing a compact four-layer wearable PCBA and need your fastest
written fabrication and prototype-assembly schedule.

Preliminary build:

- 45.8 x 18.0 mm rounded board;
- 0.80 mm finished thickness;
- four copper layers;
- approximately 70 references, all reflow parts top-side;
- 0201 passives, nPM1300 QFN, serial-NAND WSON, Raytac nRF52840 module;
- mid-mount USB-C and two digital MEMS microphones;
- quantity 12, but build exactly FA-001 and FA-002 first and hold ten.

The design is still under engineering review. This message requests capability,
DFM/stack-up coordination, component availability, and a capacity hold. It is
not a fabrication release or purchase authorization.

Please return:

1. The fastest written date for bare boards and for two assembled first articles.
2. Exact 0.80 mm four-layer stack-up and 90-ohm USB geometry.
3. Confirmation of 5/5 mil, 0.20/0.45 mm vias, and proposed 0.16/0.36 mm USB
   fanout capability.
4. Confirmation of mid-mount plated slots, 0201, QFN exposed pad, WSON exposed
   pad, stencil, AOI, and X-ray capability.
5. Critical BOM stock gaps and whether you can source or require consigned parts.
6. NRE, board, stencil, assembly, inspection, and rush costs.
7. The time final released files must arrive to preserve the quoted slot.

Final Gerbers, drills, IPC-356, released BOM, CPL, drawings, STEP, programming,
test files, and checksums will follow only after engineering release.

Thank you.

## MakerLabs - aluminum capability hold

To: `hello@makerlabs.com`  
Subject: `Monday same-day aluminum request - Anticipy pendant faces`

Hi,

We need a capability and schedule check for twelve tiny front faces and twelve
tiny rear faces for a 51 x 21 mm wearable pendant.

Requested material/process:

- 0.60 mm 5052-H32 aluminum;
- fine vertical brushed finish;
- laser-cut perimeter from final vector PDF/DXF;
- deburred edges;
- small centred ANTICIPY laser mark;
- same-day Monday service if available.

Final vector files are not yet released. Please confirm whether the exact sheet
stock, brushing, deburring, laser marking, and same-day capacity are available;
also provide the file cutoff time, total price, and pickup time. Do not begin
cutting until the final dated files are sent and approved.

Thank you.

