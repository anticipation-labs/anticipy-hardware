ANTICIPY PENDANT - 500 mAh - PRINT FILES
Units: millimetres. Binary STL. Two watertight solids that assemble.

FILES
  anticipy-500-front-half.stl   LED/mic face + board bay        313284 tri, 0 open edges
  anticipy-500-back-half.stl    battery bay + integral tongue   353928 tri, 0 open edges
  coupon-A-tongue.stl           fit test, 4 tongues             165676 tri, 0 open edges
  coupon-B-groove.stl           fit test, grooves 0.15/0.25/0.35/0.45

SHELL        68.0 x 27.7 x 23.0 stadium, faces dome 1.0, edge radius 2.2, seam on the side profile
BOARD BAY    19.2 x 22.2 x 7.6 deep   XIAO nRF52840 Sense 21.0 x 17.8, headers clipped (6.6 stack)
BATTERY BAY  21.7 x 46.5 x 9.1 deep   LiPo 44 x 20.5 x 8.5 plus tab/wire/PCM slack
CABLE PORT   9.2 x 3.6 through the bottom end wall, 1.2 chamfer lead-in.
             The 14 x 8 receptacle clearance envelope sits inside the board bay - a 14 mm
             slot cannot exit a 27.7 mm stadium end without breaking out through the sides.
CHAIN        4.5 through-hole in the solid top end, chamfered both mouths. No printed chain.
CLOSURE      Integral tongue-and-groove, 1.0 wide, full perimeter, cut at 0.25 clearance.
             Plus 2x M1.4 from the back (3.0 counterbore, 1.15 pilot) and a pry notch.
             Print the coupons first; if another step fits better, set the slider in the
             viewer (anticipy-pendant.html) and re-export.
WALLS        1.0 minimum everywhere by construction: every cavity is clamped to a 3.0 inset
             of the outline = 1.0 outer wall + 1.0 tongue + 1.0 inner lip.

SLICER - 0.4 mm nozzle, PLA or PETG
  Orientation   both halves RIM DOWN, flat on the bed
  Supports      none
  Layer         0.12 mm
  Walls         3 perimeters
  Infill        15% gyroid
  Brim          not needed, the rim is a large flat footprint

Facets are 0.40 mm; on the 13.85 mm end radius that is ~1.4 um of chord error, far below
what FDM resolves. Both halves audited: every edge used exactly twice, no open edges,
nothing for the slicer to repair.
