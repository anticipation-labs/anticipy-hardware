# Anticipy Tuesday software package v0.2

This package is the smallest honest software handoff for the Tuesday EVT pendant. It contains a rebuilt firmware image, source, and a minimal iPhone app project. The frozen `Anticipy_Tuesday_EVT_v0.1` package was not changed.

## What works in software

- The firmware compiles for the XIAO nRF52840 Sense and produces a flashable UF2.
- The pendant advertises over BLE, emits raw 16 kHz mono Opus packets, saves an offline backlog to microSD, and supports resume-safe backfill in 440-byte records.
- The iPhone app finds nearby Anticipy pendants, remembers the selected pendant, reconnects, counts live packets, requests backlog recovery, and saves received raw data locally.
- A deliberate boot gesture clears the one saved BLE bond and the offline audio file before factory handoff.

## What is not finished

- The iPhone app does **not** decode, play, transcribe, or upload Opus audio. It proves transport only.
- No iPhone or physical pendant was available in this build environment, so BLE, audio quality, background behavior, battery life, and the reset gesture remain hardware tests.
- Offline audio on microSD and the iPhone's raw debug archives are **plaintext**. Use synthetic or explicitly non-sensitive test audio only.
- This is not App Store or public-TestFlight ready. Direct Xcode installation is the Tuesday route.

## Do this first

1. Flash `FIRMWARE/Anticipy_Tuesday_EVT_v0.9.1.uf2` using `FIRMWARE/FLASH_AND_RESET.md`.
2. Install the app using `IOS_APP/INSTALL_ON_IPHONE.md`.
3. Run every item in `TUESDAY_TEST_REPORT.md` before sealing or handing over a unit.
4. After factory testing, perform the 8-second factory-reset gesture and make the recipient pair from a clean iPhone.

Do not give a recipient a pendant merely because the files compile. A passing physical acceptance test is required for every unit.
