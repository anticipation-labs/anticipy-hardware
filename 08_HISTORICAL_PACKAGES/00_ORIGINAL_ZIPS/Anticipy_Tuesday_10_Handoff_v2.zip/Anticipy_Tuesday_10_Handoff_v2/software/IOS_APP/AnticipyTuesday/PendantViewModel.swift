import Foundation

@MainActor
final class PendantViewModel: ObservableObject {
    @Published var status = "Starting"
    @Published var errorMessage: String?
    @Published var devices: [AnticipyPendant] = []
    @Published var selectedID: UUID?
    @Published var connected = false
    @Published var ready = false
    @Published var liveFrames = 0
    @Published var backlogFrames = 0
    @Published var backlogCommitted: UInt32 = 0
    @Published var backlogTotal: UInt32 = 0
    @Published var lastButtonEvent: UInt8?

    private let client = AnticipyBLEClient()
    private let liveArchive: OpusFrameArchive

    init() {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("AnticipyTuesday", isDirectory: true)
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

        liveArchive = OpusFrameArchive(url: root.appendingPathComponent("live-opus.frames"))
        do {
            try client.setBacklogSink(root.appendingPathComponent("backlog-440-byte-records.bin"))
        } catch {
            errorMessage = "Could not create the local backlog file: \(error.localizedDescription)"
        }

        bindClient()
        client.start()
    }

    var selectedName: String {
        guard let selectedID else { return "No pendant selected" }
        return devices.first(where: { $0.id == selectedID })?.name ?? "Anticipy Founder"
    }

    var backlogProgress: Double {
        guard backlogTotal > 0 else { return 0 }
        return min(1, Double(backlogCommitted) / Double(backlogTotal))
    }

    var liveDuration: String { Self.duration(forFrames: liveFrames) }
    var backlogDuration: String { Self.duration(forFrames: backlogFrames) }

    func choose(_ pendant: AnticipyPendant) {
        selectedID = pendant.id
        status = "Connecting"
        errorMessage = nil
        client.connect(to: pendant.id)
    }

    func refresh() {
        errorMessage = nil
        client.scan()
    }

    func requestBackfill() {
        errorMessage = nil
        client.requestBackfill()
    }

    func testHaptic() {
        client.playHaptic(level: 2)
    }

    func forgetPendant() {
        selectedID = nil
        connected = false
        ready = false
        status = "Choose your Anticipy"
        client.forgetSelectedPendant()
    }

    private func bindClient() {
        client.onState = { [weak self] value in
            Task { @MainActor in self?.status = value }
        }
        client.onError = { [weak self] value in
            Task { @MainActor in self?.errorMessage = value }
        }
        client.onDevices = { [weak self] values in
            Task { @MainActor in self?.devices = values }
        }
        client.onConnection = { [weak self] isConnected, id in
            Task { @MainActor in
                self?.connected = isConnected
                self?.selectedID = id ?? self?.selectedID
                if !isConnected { self?.ready = false }
            }
        }
        client.onReady = { [weak self] in
            Task { @MainActor in
                self?.ready = true
                self?.status = "Connected and receiving"
                self?.client.requestBackfill()
            }
        }
        client.onLiveOpusFrame = { [weak self] frame in
            self?.liveArchive.append(frame)
            Task { @MainActor in
                guard let self else { return }
                self.liveFrames += 1
            }
        }
        client.onBacklogOpusFrame = { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                self.backlogFrames += 1
            }
        }
        client.onBacklogTotal = { [weak self] total in
            Task { @MainActor in self?.backlogTotal = total }
        }
        client.onBacklogProgress = { [weak self] committed, total in
            Task { @MainActor in
                self?.backlogCommitted = committed
                self?.backlogTotal = total
            }
        }
        client.onButton = { [weak self] event in
            Task { @MainActor in self?.lastButtonEvent = event }
        }
    }

    private static func duration(forFrames count: Int) -> String {
        let seconds = count / 100
        if seconds < 60 { return "\(seconds)s" }
        return "\(seconds / 60)m \(seconds % 60)s"
    }
}
