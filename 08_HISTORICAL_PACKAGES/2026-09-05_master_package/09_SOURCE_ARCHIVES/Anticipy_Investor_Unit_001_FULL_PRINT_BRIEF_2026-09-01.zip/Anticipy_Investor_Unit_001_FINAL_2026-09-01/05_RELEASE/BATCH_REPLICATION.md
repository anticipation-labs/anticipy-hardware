# Ten-unit replication gate

Do not start Units 002–010 until Unit 001 has a signed PASS with no waiver.

Freeze these values from Unit 001:

| Control | Frozen value |
|---|---|
| Battery maker/MPN/lot | ______________________________ |
| Motor maker/MPN/lot | ______________________________ |
| Driver circuit/polarity/FET/diode/resistor packages | ______________________________ |
| Finished driver dimensions | ______________________________ |
| Screw-band/post variant and STL hashes | ______________________________ |
| Screw PID/length/finish/body-hole diameter | ______________________________ |
| Printer/profile/filament lot | ______________________________ |
| Alternate adhesive/TDS/lot/process/cure, if used | ______________________________ |
| Firmware SHA-256 matched to hardware pair | ______________________________ |
| TestFlight/app version | ______________________________ |

Order/buy the held **11 additional same-lot batteries** only after Unit 001
passes. Assemble nine more finished units (Units 002–010) and keep two complete
sets as labelled, unassembled spare kits. Total target is 12 physical sets:
ten intended units plus two spares. Use the same motor and driver lot where
possible.

For every serial number repeat at minimum: visual identity, firmware hash/full
erase, battery docs/polarity/OCV, component gauges, no-load closure, charging
current, Phone A owner/reconnect and Phone B rejection, 15-minute closed audio,
haptic/noise/reset, 5 m/10 m RF, 30-minute thermal smoke, shake/rattle, USB
handling, exterior finish, and final pouch inspection. Unit 001 alone also
carries the longer soak/drop/screw-retention qualification evidence.

Any substitution, print-profile change, firmware/app change, or unexplained
failure stops the batch and returns one unit through the full Unit 001 record.
