/*
 * Encrypted, power-cut-recoverable short audio backlog for XIAO nRF52840
 * Sense. The public entry points intentionally match sdcard.h so the hardened
 * transport can select SD or onboard QSPI without duplicating its queueing
 * logic.
 *
 * P25Q16H layout (2 MiB, 4 KiB erase sectors):
 *   sectors 0..1   alternating append-only metadata journals
 *   sectors 2..511 circular record arena
 *
 * Each 440-byte audio block is AES-256-CCM encrypted with a 16-byte tag. A
 * device-unique random key and nonce prefix are held separately in internal
 * settings/NVS. The nonce is prefix || generation || sequence || domain, so a
 * (key, nonce) pair is never reused. Record state bits only move from
 * ERASED -> PREPARED -> COMMITTED -> RECLAIMED. A torn record is skipped; it
 * never causes earlier committed, unacknowledged audio to be erased.
 */

#include "sdcard.h"

#include <errno.h>
#include <limits.h>
#include <stddef.h>
#include <string.h>
#include <mbedtls/ccm.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/flash.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/pm/device.h>
#include <zephyr/random/random.h>
#include <zephyr/settings/settings.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/sys/crc.h>
#include <zephyr/sys/util.h>

LOG_MODULE_REGISTER(qspi_backlog, CONFIG_LOG_DEFAULT_LEVEL);

#define QSPI_NODE DT_NODELABEL(p25q16h)
#define QSPI_FLASH_BYTES (DT_PROP(QSPI_NODE, size) / 8U)

#define QSPI_SECTOR_BYTES 4096U
#define QSPI_META_SECTORS 2U
#define QSPI_DATA_BASE (QSPI_META_SECTORS * QSPI_SECTOR_BYTES)
#define QSPI_DATA_SECTORS ((QSPI_FLASH_BYTES / QSPI_SECTOR_BYTES) - QSPI_META_SECTORS)

#define QSPI_AUDIO_BYTES 440U
#define QSPI_TAG_BYTES 16U
#define QSPI_NONCE_BYTES 13U
#define QSPI_KEY_BYTES 32U
#define QSPI_INVALID_SLOT UINT16_MAX

/* NOR-safe monotonic record-state transitions (only 1 -> 0 writes). */
#define QSPI_RECORD_ERASED UINT32_MAX
#define QSPI_RECORD_PREPARED 0xfffffffeU
#define QSPI_RECORD_COMMITTED 0xfffffffcU
#define QSPI_RECORD_RECLAIMED 0xfffffff8U

#define QSPI_META_MAGIC 0x41514d32U   /* "AQM2" */
#define QSPI_META_COMMIT 0x434f4d54U  /* "COMT" */
#define QSPI_KEY_MAGIC 0x41514b31U    /* "AQK1" */
#define QSPI_KEY_VERSION 1U
#define QSPI_KEY_SETTINGS_PATH "anticipy_qspi/key"
#define QSPI_STATUS_FLAG_FULL BIT(0)
/* Active-record corruption fails mount closed, making storage/status
 * unavailable without rewriting suspect flash.  Keep this bit reserved for a
 * future diagnostic journal that can persist it without touching that data. */
#define QSPI_STATUS_FLAG_CORRUPTION BIT(1)

struct qspi_record {
    uint32_t marker;
    uint32_t generation;
    uint32_t sequence;
    uint32_t crc;
    uint8_t ciphertext[QSPI_AUDIO_BYTES];
    uint8_t tag[QSPI_TAG_BYTES];
};

struct qspi_meta {
    uint32_t magic;
    uint32_t revision;
    uint32_t generation;
    uint32_t head_sequence;
    uint32_t tail_hint;
    uint32_t loss_count;
    uint32_t flags;
    uint32_t crc;
    uint32_t commit;
};

struct qspi_key_material {
    uint32_t magic;
    uint32_t version;
    uint32_t nonce_prefix;
    uint8_t key[QSPI_KEY_BYTES];
    uint32_t crc;
};

#define QSPI_RECORDS_PER_SECTOR (QSPI_SECTOR_BYTES / sizeof(struct qspi_record))
#define QSPI_TOTAL_RECORDS (QSPI_DATA_SECTORS * QSPI_RECORDS_PER_SECTOR)
#define QSPI_META_SLOTS (QSPI_SECTOR_BYTES / sizeof(struct qspi_meta))

BUILD_ASSERT(QSPI_FLASH_BYTES == (2U * 1024U * 1024U), "unexpected XIAO QSPI capacity");
BUILD_ASSERT(sizeof(struct qspi_record) == 472U, "encrypted record layout changed");
BUILD_ASSERT(QSPI_RECORDS_PER_SECTOR == 8U, "record packing changed");
BUILD_ASSERT(QSPI_TOTAL_RECORDS == 4080U, "backlog capacity changed");
BUILD_ASSERT(sizeof(struct qspi_meta) == 36U, "metadata layout changed");
BUILD_ASSERT(sizeof(struct qspi_key_material) == 48U, "key layout changed");
BUILD_ASSERT((sizeof(struct qspi_record) % 4U) == 0U, "record must be word aligned");
BUILD_ASSERT((sizeof(struct qspi_meta) % 4U) == 0U, "metadata must be word aligned");

/* Compatibility with the inherited single-file BLE storage protocol. */
uint8_t file_count = 1U;
uint32_t file_num_array[2];

static const struct device *const qspi_dev = DEVICE_DT_GET(QSPI_NODE);
K_MUTEX_DEFINE(qspi_mutex);

static struct qspi_meta state;
static struct qspi_key_material key_material;
static mbedtls_ccm_context ccm;
static uint16_t slot_by_sequence[QSPI_TOTAL_RECORDS];
static uint16_t write_slot;
static int meta_sector = -1;
static int meta_slot = -1;
static bool qspi_mounted;
static bool qspi_online;
static bool tail_dirty;
static bool metadata_dirty;
static bool ccm_initialized;
/* All backend entry points hold qspi_mutex, so shared work buffers avoid
 * consuming most of the 2 KiB main stack during boot recovery. */
static struct qspi_record work_record_a;
static struct qspi_record work_record_b;
static uint8_t crypto_scratch[QSPI_AUDIO_BYTES];

static uint32_t sequence_offset(uint32_t sequence)
{
    return sequence * QSPI_AUDIO_BYTES;
}

static off_t metadata_offset(uint32_t sector, uint32_t slot)
{
    return (off_t)(sector * QSPI_SECTOR_BYTES + slot * sizeof(struct qspi_meta));
}

static off_t record_offset_from_slot(uint32_t slot)
{
    uint32_t sector = slot / QSPI_RECORDS_PER_SECTOR;
    uint32_t in_sector = slot % QSPI_RECORDS_PER_SECTOR;

    return (off_t)(QSPI_DATA_BASE + sector * QSPI_SECTOR_BYTES +
                   in_sector * sizeof(struct qspi_record));
}

static uint32_t key_crc(const struct qspi_key_material *material)
{
    return crc32_ieee((const uint8_t *)material,
                      offsetof(struct qspi_key_material, crc));
}

static uint32_t metadata_crc(const struct qspi_meta *meta)
{
    return crc32_ieee((const uint8_t *)meta, offsetof(struct qspi_meta, crc));
}

static uint32_t record_crc(const struct qspi_record *record)
{
    uint32_t crc = crc32_ieee((const uint8_t *)&record->generation,
                              sizeof(record->generation) + sizeof(record->sequence));
    crc = crc32_ieee_update(crc, record->ciphertext, sizeof(record->ciphertext));
    return crc32_ieee_update(crc, record->tag, sizeof(record->tag));
}

static bool metadata_valid(const struct qspi_meta *meta)
{
    return meta->magic == QSPI_META_MAGIC && meta->commit == QSPI_META_COMMIT &&
           meta->generation != 0U && meta->head_sequence <= meta->tail_hint &&
           meta->tail_hint <= UINT32_MAX / QSPI_AUDIO_BYTES &&
           meta->tail_hint - meta->head_sequence <= QSPI_TOTAL_RECORDS &&
           meta->crc == metadata_crc(meta);
}

static bool record_marker_valid(uint32_t marker)
{
    return marker == QSPI_RECORD_COMMITTED || marker == QSPI_RECORD_RECLAIMED;
}

static int qspi_resume_locked(void)
{
    if (qspi_online) {
        return 0;
    }
    if (!device_is_ready(qspi_dev)) {
        return -ENODEV;
    }

    int rc = pm_device_action_run(qspi_dev, PM_DEVICE_ACTION_RESUME);
    if (rc != 0 && rc != -EALREADY && rc != -ENOTSUP) {
        return rc;
    }
    qspi_online = true;
    return 0;
}

static void make_nonce(uint32_t generation,
                       uint32_t sequence,
                       uint8_t nonce[QSPI_NONCE_BYTES])
{
    sys_put_le32(key_material.nonce_prefix, nonce);
    sys_put_le32(generation, nonce + 4);
    sys_put_le32(sequence, nonce + 8);
    nonce[12] = 0x41U; /* Audio-record domain separator. */
}

static void make_aad(uint32_t generation, uint32_t sequence, uint8_t aad[8])
{
    sys_put_le32(generation, aad);
    sys_put_le32(sequence, aad + 4);
}

static int encrypt_record(struct qspi_record *record,
                          const uint8_t plaintext[QSPI_AUDIO_BYTES])
{
    uint8_t nonce[QSPI_NONCE_BYTES];
    uint8_t aad[8];
    make_nonce(record->generation, record->sequence, nonce);
    make_aad(record->generation, record->sequence, aad);

    int rc = mbedtls_ccm_encrypt_and_tag(&ccm,
                                         QSPI_AUDIO_BYTES,
                                         nonce,
                                         sizeof(nonce),
                                         aad,
                                         sizeof(aad),
                                         plaintext,
                                         record->ciphertext,
                                         record->tag,
                                         sizeof(record->tag));
    return rc == 0 ? 0 : -EIO;
}

static int decrypt_record(const struct qspi_record *record,
                          uint8_t plaintext[QSPI_AUDIO_BYTES])
{
    uint8_t nonce[QSPI_NONCE_BYTES];
    uint8_t aad[8];
    make_nonce(record->generation, record->sequence, nonce);
    make_aad(record->generation, record->sequence, aad);

    int rc = mbedtls_ccm_auth_decrypt(&ccm,
                                      QSPI_AUDIO_BYTES,
                                      nonce,
                                      sizeof(nonce),
                                      aad,
                                      sizeof(aad),
                                      record->ciphertext,
                                      plaintext,
                                      record->tag,
                                      sizeof(record->tag));
    return rc == 0 ? 0 : -EBADMSG;
}

static int key_load_cb(const char *name,
                       size_t len,
                       settings_read_cb read_cb,
                       void *cb_arg,
                       void *param)
{
    ARG_UNUSED(name);
    struct qspi_key_material *material = param;
    if (len != sizeof(*material)) {
        return 0;
    }
    ssize_t loaded = read_cb(cb_arg, material, sizeof(*material));
    return loaded == (ssize_t)sizeof(*material) ? 1 : 0;
}

static int initialize_cipher_locked(bool create_new)
{
    int rc;
    memset(&key_material, 0, sizeof(key_material));

    if (create_new) {
        key_material.magic = QSPI_KEY_MAGIC;
        key_material.version = QSPI_KEY_VERSION;
        rc = sys_csrand_get(&key_material.nonce_prefix,
                            sizeof(key_material.nonce_prefix));
        if (rc < 0) {
            return rc;
        }
        rc = sys_csrand_get(key_material.key, sizeof(key_material.key));
        if (rc < 0) {
            return rc;
        }
        key_material.crc = key_crc(&key_material);
        rc = settings_save_one(QSPI_KEY_SETTINGS_PATH,
                               &key_material,
                               sizeof(key_material));
        if (rc < 0) {
            memset(&key_material, 0, sizeof(key_material));
            return rc;
        }
        /* Do not encrypt the first record until the separately persisted key
         * can be read back byte-for-byte.  A lost key would make every
         * otherwise valid committed record permanently unreadable. */
        struct qspi_key_material persisted;
        memset(&persisted, 0, sizeof(persisted));
        rc = settings_load_subtree_direct(QSPI_KEY_SETTINGS_PATH,
                                          key_load_cb,
                                          &persisted);
        if (rc < 0 || persisted.crc != key_crc(&persisted) ||
            memcmp(&persisted, &key_material, sizeof(persisted)) != 0) {
            memset(&key_material, 0, sizeof(key_material));
            memset(&persisted, 0, sizeof(persisted));
            return -EKEYREJECTED;
        }
        memset(&persisted, 0, sizeof(persisted));
    } else {
        rc = settings_load_subtree_direct(QSPI_KEY_SETTINGS_PATH,
                                          key_load_cb,
                                          &key_material);
        if (rc < 0 || key_material.magic != QSPI_KEY_MAGIC ||
            key_material.version != QSPI_KEY_VERSION ||
            key_material.crc != key_crc(&key_material)) {
            memset(&key_material, 0, sizeof(key_material));
            return -EKEYREJECTED;
        }
    }

    if (!ccm_initialized) {
        mbedtls_ccm_init(&ccm);
        ccm_initialized = true;
    }
    rc = mbedtls_ccm_setkey(&ccm,
                            MBEDTLS_CIPHER_ID_AES,
                            key_material.key,
                            QSPI_KEY_BYTES * 8U);
    return rc == 0 ? 0 : -EKEYREJECTED;
}

static bool bytes_erased(const uint8_t *bytes, size_t length)
{
    for (size_t i = 0; i < length; ++i) {
        if (bytes[i] != 0xffU) {
            return false;
        }
    }
    return true;
}

static int flash_all_erased_locked(bool *erased)
{
    uint8_t chunk[64];
    *erased = true;
    for (off_t address = 0; address < (off_t)QSPI_FLASH_BYTES;
         address += sizeof(chunk)) {
        int rc = flash_read(qspi_dev, address, chunk, sizeof(chunk));
        if (rc < 0) {
            return rc;
        }
        if (!bytes_erased(chunk, sizeof(chunk))) {
            *erased = false;
            return 0;
        }
    }
    return 0;
}

static int read_record_slot_locked(uint32_t slot, struct qspi_record *record)
{
    return flash_read(qspi_dev,
                      record_offset_from_slot(slot),
                      record,
                      sizeof(*record));
}

static bool record_integrity_valid(const struct qspi_record *record,
                                   uint8_t scratch[QSPI_AUDIO_BYTES])
{
    return record_marker_valid(record->marker) &&
           record->crc == record_crc(record) &&
           decrypt_record(record, scratch) == 0;
}

static void update_public_state_locked(void)
{
    file_count = 1U;
    file_num_array[0] = sequence_offset(state.tail_hint);
    file_num_array[1] = sequence_offset(state.head_sequence);
}

static int metadata_slot_erased_locked(uint32_t sector, uint32_t slot, bool *erased)
{
    struct qspi_meta meta;
    int rc = flash_read(qspi_dev, metadata_offset(sector, slot), &meta, sizeof(meta));
    if (rc < 0) {
        return rc;
    }
    *erased = bytes_erased((const uint8_t *)&meta, sizeof(meta));
    return 0;
}

static int select_metadata_slot_locked(int *target_sector, int *target_slot)
{
    bool erased;
    int sector = meta_sector < 0 ? 0 : meta_sector;
    int first_slot = meta_sector < 0 ? 0 : meta_slot + 1;

    for (int slot = first_slot; slot < (int)QSPI_META_SLOTS; ++slot) {
        int rc = metadata_slot_erased_locked((uint32_t)sector,
                                             (uint32_t)slot,
                                             &erased);
        if (rc < 0) {
            return rc;
        }
        if (erased) {
            *target_sector = sector;
            *target_slot = slot;
            return 0;
        }
    }

    sector ^= 1;
    int rc = flash_erase(qspi_dev,
                         (off_t)sector * QSPI_SECTOR_BYTES,
                         QSPI_SECTOR_BYTES);
    if (rc < 0) {
        return rc;
    }
    *target_sector = sector;
    *target_slot = 0;
    return 0;
}

static int commit_metadata_locked(void)
{
    int rc = qspi_resume_locked();
    if (rc < 0) {
        return rc;
    }

    int target_sector;
    int target_slot;
    rc = select_metadata_slot_locked(&target_sector, &target_slot);
    if (rc < 0) {
        return rc;
    }

    struct qspi_meta next = state;
    next.magic = QSPI_META_MAGIC;
    next.revision = state.revision + 1U;
    if (next.revision == 0U) {
        next.revision = 1U;
    }
    next.crc = metadata_crc(&next);
    next.commit = UINT32_MAX;

    off_t address = metadata_offset((uint32_t)target_sector,
                                    (uint32_t)target_slot);
    rc = flash_write(qspi_dev, address, &next, offsetof(struct qspi_meta, commit));
    if (rc < 0) {
        return rc;
    }

    const uint32_t commit = QSPI_META_COMMIT;
    rc = flash_write(qspi_dev,
                     address + offsetof(struct qspi_meta, commit),
                     &commit,
                     sizeof(commit));
    if (rc < 0) {
        return rc;
    }

    next.commit = commit;
    struct qspi_meta verify;
    rc = flash_read(qspi_dev, address, &verify, sizeof(verify));
    if (rc < 0) {
        return rc;
    }
    /* In particular, ACK callers may report success only after the exact
     * commit-last entry is readable and validates from flash. */
    if (!metadata_valid(&verify) ||
        memcmp(&verify, &next, sizeof(verify)) != 0) {
        return -EIO;
    }
    state = next;
    meta_sector = target_sector;
    meta_slot = target_slot;
    tail_dirty = false;
    metadata_dirty = false;
    update_public_state_locked();
    return 0;
}

static int find_latest_metadata_locked(void)
{
    struct qspi_meta candidate;
    bool found = false;
    memset(&state, 0, sizeof(state));
    meta_sector = -1;
    meta_slot = -1;

    for (uint32_t sector = 0; sector < QSPI_META_SECTORS; ++sector) {
        for (uint32_t slot = 0; slot < QSPI_META_SLOTS; ++slot) {
            int rc = flash_read(qspi_dev,
                                metadata_offset(sector, slot),
                                &candidate,
                                sizeof(candidate));
            if (rc < 0) {
                return rc;
            }
            if (!metadata_valid(&candidate)) {
                continue;
            }
            if (!found || candidate.revision > state.revision) {
                state = candidate;
                meta_sector = (int)sector;
                meta_slot = (int)slot;
                found = true;
            }
        }
    }
    return found ? 0 : -ENOENT;
}

static int initialize_metadata_locked(void)
{
    memset(&state, 0, sizeof(state));
    state.generation = 1U;
    meta_sector = -1;
    meta_slot = -1;
    metadata_dirty = true;
    return commit_metadata_locked();
}

static int record_slot_for_sequence_locked(uint32_t sequence,
                                           uint16_t *slot,
                                           struct qspi_record *record)
{
    uint16_t candidate = slot_by_sequence[sequence % QSPI_TOTAL_RECORDS];
    if (candidate == QSPI_INVALID_SLOT) {
        return -ENOENT;
    }
    int rc = read_record_slot_locked(candidate, record);
    if (rc < 0) {
        return rc;
    }
    if (record->generation != state.generation || record->sequence != sequence ||
        !record_marker_valid(record->marker) || record->crc != record_crc(record)) {
        return -EBADMSG;
    }
    *slot = candidate;
    return 0;
}

static int finish_reclaim_locked(uint32_t first, uint32_t target)
{
    struct qspi_record record;
    for (uint32_t slot = 0; slot < QSPI_TOTAL_RECORDS; ++slot) {
        int rc = read_record_slot_locked(slot, &record);
        if (rc < 0) {
            return rc;
        }
        if (record.marker == QSPI_RECORD_COMMITTED &&
            record.generation == state.generation &&
            record.sequence >= first && record.sequence < target) {
            const uint32_t reclaimed = QSPI_RECORD_RECLAIMED;
            rc = flash_write(qspi_dev,
                             record_offset_from_slot(slot) +
                                 offsetof(struct qspi_record, marker),
                             &reclaimed,
                             sizeof(reclaimed));
            if (rc < 0) {
                return rc;
            }
        }
    }
    return 0;
}

static int recover_records_locked(void)
{
    struct qspi_record *record = &work_record_a;
    struct qspi_record *mapped = &work_record_b;
    uint32_t recovered_tail = state.tail_hint;
    uint32_t newest_sequence = 0U;
    uint16_t newest_slot = 0U;
    bool found = false;
    memset(slot_by_sequence, 0xff, sizeof(slot_by_sequence));

    for (uint32_t slot = 0; slot < QSPI_TOTAL_RECORDS; ++slot) {
        int rc = read_record_slot_locked(slot, record);
        if (rc < 0) {
            return rc;
        }
        if (!record_marker_valid(record->marker) ||
            record->generation != state.generation) {
            continue;
        }
        if (!record_integrity_valid(record, crypto_scratch)) {
            continue;
        }

        uint32_t index = record->sequence % QSPI_TOTAL_RECORDS;
        uint16_t previous = slot_by_sequence[index];
        if (previous != QSPI_INVALID_SLOT) {
            rc = read_record_slot_locked(previous, mapped);
            if (rc < 0) {
                return rc;
            }
            if (mapped->sequence > record->sequence) {
                continue;
            }
        }
        slot_by_sequence[index] = (uint16_t)slot;
        if (!found || record->sequence > newest_sequence) {
            newest_sequence = record->sequence;
            newest_slot = (uint16_t)slot;
            found = true;
        }
    }

    if (found && newest_sequence < UINT32_MAX / QSPI_AUDIO_BYTES) {
        recovered_tail = MAX(recovered_tail, newest_sequence + 1U);
        write_slot = (uint16_t)((newest_slot + 1U) % QSPI_TOTAL_RECORDS);
    } else {
        write_slot = 0U;
    }

    if (recovered_tail > UINT32_MAX / QSPI_AUDIO_BYTES) {
        return -EOVERFLOW;
    }
    state.tail_hint = recovered_tail;

    /* A metadata ACK is durable before its marker sweep. Finish any sweep
     * interrupted by a power cut before exposing the status to the app. */
    uint32_t reclaim_first = state.head_sequence > QSPI_TOTAL_RECORDS ?
                                 state.head_sequence - QSPI_TOTAL_RECORDS :
                                 0U;
    int rc = finish_reclaim_locked(reclaim_first, state.head_sequence);
    if (rc < 0) {
        return rc;
    }

    /* The active interval must be contiguous. Advancing head around a corrupt
     * record would silently discard earlier valid, unacknowledged audio. Fail
     * closed and leave the flash untouched; main will continue live BLE. */
    for (uint32_t sequence = state.head_sequence;
         sequence < state.tail_hint;
         ++sequence) {
        uint16_t slot;
        rc = record_slot_for_sequence_locked(sequence, &slot, record);
        if (rc < 0 || record->marker != QSPI_RECORD_COMMITTED ||
            decrypt_record(record, crypto_scratch) < 0) {
            LOG_ERR("QSPI active interval corrupt at epoch %u sequence %u",
                    state.generation, sequence);
            return -EILSEQ;
        }
    }
    update_public_state_locked();
    return 0;
}

static int slot_erased_locked(uint32_t slot, bool *erased)
{
    struct qspi_record record;
    int rc = read_record_slot_locked(slot, &record);
    if (rc < 0) {
        return rc;
    }
    *erased = bytes_erased((const uint8_t *)&record, sizeof(record));
    return 0;
}

static int sector_has_active_records_locked(uint32_t data_sector, bool *active)
{
    struct qspi_record record;
    *active = false;
    uint32_t first = data_sector * QSPI_RECORDS_PER_SECTOR;
    for (uint32_t i = 0; i < QSPI_RECORDS_PER_SECTOR; ++i) {
        int rc = read_record_slot_locked(first + i, &record);
        if (rc < 0) {
            return rc;
        }
        if (record.marker == QSPI_RECORD_COMMITTED &&
            record.generation == state.generation &&
            record.sequence >= state.head_sequence) {
            *active = true;
            return 0;
        }
    }
    return 0;
}

static int find_writable_slot_locked(uint16_t *selected)
{
    uint32_t cursor = write_slot;
    uint32_t visited = 0U;

    while (visited < QSPI_TOTAL_RECORDS) {
        uint32_t in_sector = cursor % QSPI_RECORDS_PER_SECTOR;
        if (in_sector == 0U) {
            bool active;
            int rc = sector_has_active_records_locked(
                cursor / QSPI_RECORDS_PER_SECTOR, &active);
            if (rc < 0) {
                return rc;
            }
            if (active) {
                cursor = (cursor + QSPI_RECORDS_PER_SECTOR) % QSPI_TOTAL_RECORDS;
                visited += QSPI_RECORDS_PER_SECTOR;
                continue;
            }

            rc = flash_erase(qspi_dev,
                             (off_t)(QSPI_DATA_BASE +
                                     (cursor / QSPI_RECORDS_PER_SECTOR) *
                                         QSPI_SECTOR_BYTES),
                             QSPI_SECTOR_BYTES);
            if (rc < 0) {
                return rc;
            }
            *selected = (uint16_t)cursor;
            return 0;
        }

        bool erased;
        int rc = slot_erased_locked(cursor, &erased);
        if (rc < 0) {
            return rc;
        }
        if (erased) {
            *selected = (uint16_t)cursor;
            return 0;
        }
        cursor = (cursor + 1U) % QSPI_TOTAL_RECORDS;
        visited++;
    }
    return -ENOSPC;
}

static int note_full_locked(void)
{
    if ((state.flags & QSPI_STATUS_FLAG_FULL) != 0U) {
        return -ENOSPC;
    }
    state.flags |= QSPI_STATUS_FLAG_FULL;
    state.loss_count++;
    metadata_dirty = true;
    int rc = commit_metadata_locked();
    return rc < 0 ? rc : -ENOSPC;
}

static int append_record_locked(const uint8_t plaintext[QSPI_AUDIO_BYTES])
{
    if (state.tail_hint >= UINT32_MAX / QSPI_AUDIO_BYTES) {
        return -EOVERFLOW;
    }

    uint16_t slot;
    int rc = find_writable_slot_locked(&slot);
    if (rc == -ENOSPC) {
        return note_full_locked();
    }
    if (rc < 0) {
        return rc;
    }

    struct qspi_record *record = &work_record_a;
    struct qspi_record *verify = &work_record_b;
    memset(record, 0xff, sizeof(*record));
    record->marker = QSPI_RECORD_PREPARED;
    record->generation = state.generation;
    record->sequence = state.tail_hint;
    rc = encrypt_record(record, plaintext);
    if (rc < 0) {
        return rc;
    }
    record->crc = record_crc(record);

    off_t address = record_offset_from_slot(slot);
    rc = flash_write(qspi_dev, address, &record->marker, sizeof(record->marker));
    if (rc < 0) {
        return rc;
    }
    rc = flash_write(qspi_dev,
                     address + sizeof(record->marker),
                     (const uint8_t *)record + sizeof(record->marker),
                     sizeof(*record) - sizeof(record->marker));
    if (rc < 0) {
        return rc;
    }
    /* Do not publish a record until the exact programmed PREPARED body reads
     * back, authenticates, and decrypts to the source block. */
    rc = read_record_slot_locked(slot, verify);
    if (rc < 0 || verify->marker != QSPI_RECORD_PREPARED ||
        verify->generation != record->generation ||
        verify->sequence != record->sequence ||
        verify->crc != record_crc(verify) ||
        decrypt_record(verify, crypto_scratch) < 0 ||
        memcmp(crypto_scratch, plaintext, QSPI_AUDIO_BYTES) != 0) {
        return rc < 0 ? rc : -EIO;
    }

    const uint32_t committed = QSPI_RECORD_COMMITTED;
    rc = flash_write(qspi_dev, address, &committed, sizeof(committed));
    if (rc < 0) {
        return rc;
    }

    uint32_t committed_readback;
    rc = flash_read(qspi_dev, address, &committed_readback, sizeof(committed_readback));
    if (rc < 0 || committed_readback != QSPI_RECORD_COMMITTED) {
        return rc < 0 ? rc : -EIO;
    }

    slot_by_sequence[record->sequence % QSPI_TOTAL_RECORDS] = slot;
    state.tail_hint = record->sequence + 1U;
    state.flags &= ~QSPI_STATUS_FLAG_FULL;
    write_slot = (uint16_t)((slot + 1U) % QSPI_TOTAL_RECORDS);
    tail_dirty = true;
    update_public_state_locked();
    return QSPI_AUDIO_BYTES;
}

int mount_sd_card(void)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_resume_locked();
    if (rc < 0) {
        goto out;
    }

    /* mount_sd_card() runs before transport_start()/Bluetooth settings_load().
     * This initializer is explicitly idempotent in Zephyr. */
    rc = settings_subsys_init();
    if (rc < 0) {
        goto out;
    }

    rc = find_latest_metadata_locked();
    if (rc == -ENOENT) {
        bool erased;
        rc = flash_all_erased_locked(&erased);
        if (rc < 0) {
            goto out;
        }
        if (!erased) {
            LOG_ERR("QSPI contains unknown data; refusing destructive initialization");
            rc = -EILSEQ;
            goto out;
        }
        rc = initialize_cipher_locked(true);
        if (rc < 0) {
            goto out;
        }
        rc = initialize_metadata_locked();
    } else if (rc == 0) {
        rc = initialize_cipher_locked(false);
    }
    if (rc < 0) {
        goto out;
    }

    struct qspi_meta before = state;
    rc = recover_records_locked();
    if (rc < 0) {
        goto out;
    }
    if (metadata_dirty || memcmp(&before, &state, sizeof(state)) != 0) {
        rc = commit_metadata_locked();
        if (rc < 0) {
            goto out;
        }
    }

    qspi_mounted = true;
    update_public_state_locked();
    LOG_INF("Encrypted QSPI backlog ready: epoch %u, seq %u..%u, loss %u, capacity %u",
            state.generation,
            state.head_sequence,
            state.tail_hint,
            state.loss_count,
            QSPI_TOTAL_RECORDS);
out:
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

int write_to_file(uint8_t *data, uint32_t length)
{
    if (data == NULL || length == 0U || (length % QSPI_AUDIO_BYTES) != 0U) {
        return -EINVAL;
    }

    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_mounted ? qspi_resume_locked() : -ENODEV;
    uint32_t written = 0U;
    while (rc == 0 && written < length) {
        rc = append_record_locked(data + written);
        if (rc == QSPI_AUDIO_BYTES) {
            written += QSPI_AUDIO_BYTES;
            rc = 0;
        }
    }
    k_mutex_unlock(&qspi_mutex);
    return rc < 0 ? rc : (int)written;
}

int flush_audio_file(bool close_file)
{
    ARG_UNUSED(close_file);
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = 0;
    if (qspi_mounted && (tail_dirty || metadata_dirty)) {
        rc = commit_metadata_locked();
    }
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

int read_audio_data(uint8_t *buf, int amount, int offset)
{
    if (buf == NULL || amount < 0 || offset < 0) {
        return -EINVAL;
    }

    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_mounted ? qspi_resume_locked() : -ENODEV;
    uint32_t start = sequence_offset(state.head_sequence);
    uint32_t end = sequence_offset(state.tail_hint);
    uint32_t requested = (uint32_t)offset;
    uint32_t remaining = (uint32_t)amount;
    if (rc == 0 && (requested < start || requested > end ||
                    remaining > end - requested)) {
        rc = -ERANGE;
    }

    struct qspi_record *record = &work_record_a;
    uint8_t *plaintext = crypto_scratch;
    uint32_t copied = 0U;
    while (rc == 0 && remaining > 0U) {
        uint32_t sequence = requested / QSPI_AUDIO_BYTES;
        uint32_t within = requested % QSPI_AUDIO_BYTES;
        uint16_t slot;
        rc = record_slot_for_sequence_locked(sequence, &slot, record);
        if (rc < 0 || record->marker != QSPI_RECORD_COMMITTED) {
            rc = -EBADMSG;
            break;
        }
        rc = decrypt_record(record, plaintext);
        if (rc < 0) {
            break;
        }
        uint32_t chunk = MIN(remaining, QSPI_AUDIO_BYTES - within);
        memcpy(buf + copied, plaintext + within, chunk);
        requested += chunk;
        copied += chunk;
        remaining -= chunk;
    }
    memset(plaintext, 0, QSPI_AUDIO_BYTES);
    k_mutex_unlock(&qspi_mutex);
    return rc < 0 ? rc : (int)copied;
}

uint32_t get_file_size(uint8_t num)
{
    if (num != 1U) {
        return 0U;
    }
    (void)flush_audio_file(false);
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    uint32_t size = sequence_offset(state.tail_hint);
    k_mutex_unlock(&qspi_mutex);
    return size;
}

/* A transfer offset is not a durable application ACK. Only the epoch-bound
 * qspi_backlog_ack() can reclaim records. */
int save_offset(uint32_t offset)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    uint32_t start = sequence_offset(state.head_sequence);
    uint32_t end = sequence_offset(state.tail_hint);
    int rc = !qspi_mounted ? -ENODEV :
             (offset < start || offset > end) ? -ERANGE : 0;
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

int get_offset(void)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    uint32_t offset = sequence_offset(state.head_sequence);
    k_mutex_unlock(&qspi_mutex);
    return offset <= INT_MAX ? (int)offset : -ERANGE;
}

int qspi_backlog_get_status(uint32_t *generation,
                            uint32_t *head_sequence,
                            uint32_t *tail_sequence,
                            uint32_t *loss_count,
                            uint32_t *flags)
{
    if (generation == NULL || head_sequence == NULL || tail_sequence == NULL ||
        loss_count == NULL || flags == NULL) {
        return -EINVAL;
    }
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_mounted ? 0 : -ENODEV;
    if (rc == 0) {
        *generation = state.generation;
        *head_sequence = state.head_sequence;
        *tail_sequence = state.tail_hint;
        *loss_count = state.loss_count;
        *flags = state.flags;
    }
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

int qspi_backlog_ack(uint32_t generation, uint32_t target_next_sequence)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_mounted ? qspi_resume_locked() : -ENODEV;
    if (rc < 0) {
        goto out;
    }
    if (generation != state.generation) {
        rc = -ESTALE;
        goto out;
    }
    if (target_next_sequence > state.tail_hint) {
        rc = -ERANGE;
        goto out;
    }

    /* Commit the ACK boundary first. If power fails during the marker sweep,
     * recovery completes it. Repeating the same token is therefore safe. */
    uint32_t previous_head = state.head_sequence;
    if (target_next_sequence > state.head_sequence) {
        state.head_sequence = target_next_sequence;
        metadata_dirty = true;
        rc = commit_metadata_locked();
        if (rc < 0) {
            goto out;
        }
    }
    rc = finish_reclaim_locked(previous_head, state.head_sequence);
    if (rc == 0) {
        update_public_state_locked();
    }
out:
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

static int start_new_generation_locked(void)
{
    if (state.generation == UINT32_MAX) {
        return -EOVERFLOW;
    }
    state.generation++;
    state.head_sequence = 0U;
    state.tail_hint = 0U;
    state.flags = 0U;
    tail_dirty = false;
    metadata_dirty = true;
    memset(slot_by_sequence, 0xff, sizeof(slot_by_sequence));
    return commit_metadata_locked();
}

int clear_audio_directory(void)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_mounted ? start_new_generation_locked() : -ENODEV;
    if (rc == 0) {
        update_public_state_locked();
    }
    k_mutex_unlock(&qspi_mutex);
    return rc;
}

int clear_audio_file(uint8_t num)
{
    return num == 1U ? clear_audio_directory() : -EINVAL;
}

int move_read_pointer(uint8_t num)
{
    return num == 1U && qspi_mounted ? 0 : -EINVAL;
}

int move_write_pointer(uint8_t num)
{
    return num == 1U && qspi_mounted ? 0 : -EINVAL;
}

int create_file(const char *file_path)
{
    ARG_UNUSED(file_path);
    return qspi_mounted ? 0 : -ENODEV;
}

int initialize_audio_file(uint8_t num)
{
    return num == 1U && qspi_mounted ? 0 : -EINVAL;
}

char *generate_new_audio_header(uint8_t num)
{
    ARG_UNUSED(num);
    return NULL;
}

void sd_off(void)
{
    (void)flush_audio_file(true);
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    if (qspi_online) {
        int rc = pm_device_action_run(qspi_dev, PM_DEVICE_ACTION_SUSPEND);
        if (rc == 0 || rc == -EALREADY || rc == -ENOTSUP) {
            qspi_online = false;
        } else {
            LOG_ERR("QSPI suspend failed: %d", rc);
        }
    }
    k_mutex_unlock(&qspi_mutex);
}

void sd_on(void)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    int rc = qspi_resume_locked();
    if (rc < 0) {
        LOG_ERR("QSPI resume failed: %d", rc);
    }
    k_mutex_unlock(&qspi_mutex);
}

bool is_sd_on(void)
{
    k_mutex_lock(&qspi_mutex, K_FOREVER);
    bool ready = qspi_mounted && qspi_online;
    k_mutex_unlock(&qspi_mutex);
    return ready;
}
