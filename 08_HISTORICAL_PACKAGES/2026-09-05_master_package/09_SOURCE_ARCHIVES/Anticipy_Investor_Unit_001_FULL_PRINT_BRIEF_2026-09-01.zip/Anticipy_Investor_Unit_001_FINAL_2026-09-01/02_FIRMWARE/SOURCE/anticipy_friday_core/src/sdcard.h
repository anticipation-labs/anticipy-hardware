#ifndef SDCARD_H
#define SDCARD_H

#include <stdbool.h>
#include <stdint.h>

/**
 * @brief Mount the SD Card. Initializes the audio files
 *
 * Mounts the SD Card and initializes the audio files. If the SD card does not contain those files, the
 * function will create them.
 *
 * @return 0 if successful, negative errno code if error
 */
int mount_sd_card(void);

/**
 * @brief Create a file
 *
 * Creates a file at the given path
 *
 * @return 0 if successful, negative errno code if error
 */
int create_file(const char *file_path);
// private
char *generate_new_audio_header(uint8_t num);

/**
 * @brief Initialize an audio file of number 1
 *
 * Initializes an audio file. It will be called a nn.txt, where nn is the number of the file.
 *  example: initialize_audio_file(1) will create a file called a01.txt
 * @return 0 if successful, negative errno code if error
 */
int initialize_audio_file(uint8_t num);

/**
 * @brief Write to the current audio file specified by the write pointer
 *
 *
 *
 * @return number of bytes written
 */
int write_to_file(uint8_t *data, uint32_t length);

/** Flush buffered audio to the card and optionally close the append file. */
int flush_audio_file(bool close_file);

/**
 * @brief Read from the current audio file specified by the read pointer
 *
 *
 *
 * @return number of bytes read
 */
int read_audio_data(uint8_t *buf, int amount, int offset);
/**
 * @brief Get the size of the specified audio file number
 *
 *
 *
 * @return size of the file in bytes
 */
uint32_t get_file_size(uint8_t num);

/**
 * @brief Move the read pointer to the specified audio file position
 *
 *
 *
 * @return 0 if successful, negative errno code if error
 */
int move_read_pointer(uint8_t num);

/**
 * @brief Move the write pointer to the specified audio file position
 *
 *
 *
 * @return 0 if successful, negative errno code if error
 */
int move_write_pointer(uint8_t num);

/**
 * @brief Clear the specified audio file
 *
 *
 *
 * @return 0 if successful, negative errno code if error
 */
int clear_audio_file(uint8_t num);

/**
 * @brief Clear the audio directory.
 *
 * This deletes all audio files and leaves the audio directory with only one file left, a01.txt.
 * This automatically moves the read and write pointers to a01.txt.
 * @return 0 if successful, negative errno code if error
 */
int clear_audio_directory();

int save_offset(uint32_t offset);
int get_offset();

/**
 * QSPI protocol extension. The first two status words remain the legacy
 * absolute byte tail/head; these words add an idempotent ACK token and an
 * explicit loss counter.
 */
#ifdef CONFIG_OMI_OFFLINE_STORAGE_QSPI
int qspi_backlog_get_status(uint32_t *generation,
                            uint32_t *head_sequence,
                            uint32_t *tail_sequence,
                            uint32_t *loss_count,
                            uint32_t *flags);
int qspi_backlog_ack(uint32_t generation, uint32_t target_next_sequence);
#endif

void sd_on();
void sd_off();

bool is_sd_on();
#endif
