# Anticipy pendant v0.1 build pack

This pack is for one working pendant that can be built in Vancouver in seven days without waiting for a custom PCB.

## Locked physical specification

- Maximum outer envelope: **51 × 21 × 11 mm**, including the chain eyelet.
- Target assembled device weight: **13–16 g**; hard stop: **17.4 g**.
- Shape: a narrow rounded capsule with an integrated oval chain eyelet, based on the current Anticipy render but constrained to the PLAUD NotePin S envelope.
- Front shell: **6061-T6 aluminum**, bead-blasted, then clear Type II anodized for production.
- Rear shell: **polycarbonate** so Bluetooth can escape. Use tough SLA resin for the seven-day prototype.
- The chain is passive. No power or data wires run through it.

The PLAUD NotePin/NotePin S reference is aluminum alloy plus polycarbonate, not a solid metal body. A solid aluminum or titanium box would block the 2.4 GHz Bluetooth antenna. Titanium is also heavier and more expensive, so it is not the right material for this version.

## The inexpensive seven-day electronics

| Qty | Part | Exact role | Size / fit | Current one-off CAD cost |
|---:|---|---|---|---:|
| 2 | Seeed XIAO nRF52840 Sense, MPN 102010469 | BLE, processor, PDM microphone, IMU, 2 MB flash, charger, USB-C, RGB LED | 21 × 17.5/17.8 mm | $25.22 each |
| 2 | Protected 3.7 V LiPo, 100 mAh, Adafruit 1570 | Known-size battery for the first fit and runtime test | 31 × 11.5 × 3.8 mm, 3 g | about $8–10 each |
| 2 | JYC1020 10 mm 3 V ERM coin motor | Haptic feedback | 10 mm diameter | $2.28 each |
| 5 | AO3400A N-MOSFET | Switches the vibration motor | SOT-23 | $0.65 each |
| 5 | 1N4148W diode, 1 kΩ resistor, 100 kΩ resistor | Protects and controls the motor | SMD or hand-wired | under $1 per set |
| 2 | PTS845VM20PSMTR4 LFS side tactile switch | Privacy / wake / pairing button | 4.5 × 2.55 mm | about $1–2 each |
| 2 | Thin acoustic mesh + 0.3–0.5 mm foam gasket | Seals the microphone to the front port | cut to fit | under $2 each |
| 2 sets | Printed front and rear shells | First fit and backup fit | supplied STL files | quote locally |

Buy two of every critical part. One is the build; one prevents a broken wire or damaged pad from killing the seven-day schedule.

### Why this BOM is cheaper

- The XIAO already contains the processor, BLE radio, microphone, IMU, flash, charging circuit, USB-C connector, antenna and LEDs.
- The phone does transcription and AI work. The pendant does not need an expensive application processor.
- The prototype uses one onboard microphone. A custom production PCB gets two microphones.
- The pendant streams to the iPhone, so it does not need PLAUD's 64 GB storage. Its 2 MB flash is only an outage buffer.
- A simple ERM motor plus one MOSFET replaces an $8 haptic driver breakout.

Estimated electronics cost for one working prototype is **about CAD $39–45 before the shell and chain**.

Expected assembled weight is **about 14–16 g**: approximately 5.4 g for the aluminum/polycarbonate shell, 3 g for the battery, about 3 g for the XIAO, and 2–4 g for the motor, button, wiring, foam and adhesive.

## Internal layout

Hold the pendant vertically with the eyelet at the top.

1. Put the XIAO in the wide middle of the capsule.
2. Put the battery flat underneath the XIAO and toward the centre.
3. Put the vibration motor near the top, away from the microphone.
4. Put the side button in the right-side seam.
5. Face the XIAO's antenna toward the polycarbonate rear shell.
6. Face the microphone toward the front acoustic port and seal the gap with foam.
7. Keep the rear shell removable. Open it to reach USB-C for charging and firmware during this seven-day build. Add sealed magnetic charging contacts only on the later custom PCB.

The `fit_check.glb` file shows the shell and component blocks in their intended positions.

## Wiring

```text
Protected battery +  -> XIAO BAT+
Protected battery -  -> XIAO BAT-

XIAO 3V3 -----------> motor +
motor - ------------> AO3400A drain
AO3400A source ------> GND
XIAO D0 -- 1 kΩ ----> AO3400A gate
gate ---- 100 kΩ ---> GND
1N4148W across motor, stripe/cathode toward 3V3

XIAO D1 ------------> side button ------------> GND
Firmware enables D1 internal pull-up.
```

Use PWM on D0 at no more than about 70% for the first motor test. Keep haptic bursts short. Never glue directly onto the LiPo pouch, and leave at least 0.5 mm swelling clearance.

## What the first firmware must do

Only five things are required for the first seven-day unit:

1. Capture 16 kHz mono audio from the onboard PDM microphone.
2. Encode audio as IMA-ADPCM or another light codec.
3. Stream frames over a custom BLE service to the iPhone.
4. Use the external flash as a roughly three-minute compressed outage buffer.
5. Handle the button, haptic motor, RGB state LED and battery reading.

State meanings:

| State | LED | Haptic |
|---|---|---|
| Connected and listening | very dim green pulse every 10 s | none |
| Phone disconnected, buffering | amber pulse | one short buzz |
| Privacy off / microphone stopped | solid red for 2 s, then off | two short buzzes |
| Battery under 15% | red pulse every minute | one long buzz once |
| Charging | onboard charge LED | none |

## Seven-day schedule

### Day 0 — Thursday, August 27

- Pick up the XIAO nRF52840 Sense Plus and a 200 mAh LiPo from Lee's Electronic in Vancouver if the battery physically measures no more than 17.5 mm wide. Also order the known-size Adafruit 1570 battery as the backup.
- Order the remaining small electronics from DigiKey's in-stock list.
- Send `front_shell.stl` and `back_shell.stl` to Forge Labs or Ember Prototypes for a rush tough-resin print.
- Send `front_shell.stl` to Protolabs for a one-day 6061 aluminum quote. Choose bead-blasted/as-machined first; anodizing may add three days.

### Day 1 — Friday, August 28

- Solder the battery, motor circuit and side button on the bench.
- Prove: microphone records, BLE reaches the iPhone, button works and motor buzzes.

### Day 2 — Saturday, August 29

- Receive or pick up the first printed shells.
- Dry-fit every part without glue.
- Mark the exact microphone port and USB-C opening.

### Day 3 — Sunday, August 30

- Print the corrected shell if the fit is tight.
- Add the acoustic foam gasket and battery foam.
- Assemble with thin removable adhesive at the seam.

### Day 4 — Monday, August 31

- Run an eight-hour microphone, BLE and battery test.
- Walk, sit, talk, turn and cover the pendant with a shirt.

### Day 5 — Tuesday, September 1

- Fix only failures found in the wear test.
- Finish the front print in silver for the visual unit, or fit the CNC aluminum front if it has arrived.

### Day 6 — Wednesday, September 2

- Build the final unit and the backup unit.
- Drop-test from chest height onto wood and verify BLE range again.

### Day 7 — Thursday, September 3

- Fully charge, run a final two-hour recording, and deliver the working unit in Vancouver.

## Pass / fail rules

- Fits completely inside 51 × 21 × 11 mm.
- Device alone is no more than 17.4 g.
- No sharp seam touches skin or clothing.
- Continuous audio reaches the iPhone for two hours without a crash.
- Reconnects and drains the local buffer after the phone returns.
- At least six hours of real prototype runtime on 100 mAh; move to the narrow 180–200 mAh cell only after confirming its protection board and dimensions.
- Bluetooth remains stable through the polycarbonate back.
- Haptic vibration is clearly felt but does not overwhelm the microphone for more than one second.
- Rear shell opens for USB-C access and closes securely without tools.

## Production version after this prototype

The production PCB should replace the XIAO with one 4-layer board containing:

- nRF52840/nRF54-series BLE processor or certified module
- two high-SNR PDM microphones
- 128 MB flash, not 64 GB
- charger, fuel gauge and battery protection
- 180–270 mAh custom narrow LiPo with NTC
- LRA haptic motor and DRV2605-class driver
- side privacy button, RGB LED, ESD protection, factory test pads and SWD pads
- printed antenna under the polycarbonate rear window

Target production electronics BOM: **CAD $18–28 at 1,000 units**, before battery, enclosure, assembly and freight. Target landed hardware cost remains compatible with the existing roughly CAD/USD $60 planning number, but it needs supplier quotes before being treated as committed.

## AI hardware tools: what to use

| Tool | Use it for | Verdict for Anticipy |
|---|---|---|
| Makeable.build | Maker-level concept, render, parts and wiring | Good five-minute idea checker; not manufacturing output |
| Blueprint.io | Beginner BOM and assembly instructions | Good for learning; not a production wearable board |
| Flux | Browser schematic, part selection, collaboration and first layout | Best easy starting point for the custom PCB |
| Trace | Full AI-assisted schematic through Gerber/BOM/CPL, with enclosure import | Strongest one-tool trial if its current output survives human review |
| ProtoFlow + KiCad | Free first-pass schematic, real parts and local KiCad handoff | Best low-cost workflow |
| Quilter | Physics-driven placement/routing of an already-correct design | Use after the schematic is correct, not for the initial concept |
| Diode | Done-with-you design and manufacturing service | Potentially strong, but not the seven-day or low-cost path |

No AI-generated PCB goes to fabrication until a human electrical engineer checks every datasheet, runs ERC/DRC and signs off the battery, antenna, charging and microphone circuits.

## Source links

- PLAUD official hardware comparison: https://www.plaud.ai/pages/hardware-comparison
- Anticipy current public design: https://www.anticipy.ai/
- XIAO nRF52840 Sense documentation: https://wiki.seeedstudio.com/XIAO_BLE/
- DigiKey XIAO product: https://www.digikey.ca/en/products/detail/seeed-technology-co-ltd/102010469/16652896
- Adafruit 100 mAh battery: https://www.adafruit.com/product/1570
- DigiKey 10 mm haptic motor: https://www.digikey.ca/en/products/detail/jie-yi-electronics-limited/JYC1020/20193255
- DigiKey AO3400A: https://www.digikey.ca/en/products/detail/umw/AO3400A/16705910
- Lee's Electronic Vancouver: https://leeselectronic.com/
- Forge Labs Vancouver: https://forgelabs.com/3d-printing/vancouver
- Ember Prototypes Vancouver: https://www.emberprototypes.com/
- Protolabs one-day CNC: https://www.protolabs.com/services/cnc-machining/
- Flux: https://www.flux.ai/
- Trace: https://buildwithtrace.com/
- Quilter: https://www.quilter.ai/
- Diode: https://www.diode.computer/
