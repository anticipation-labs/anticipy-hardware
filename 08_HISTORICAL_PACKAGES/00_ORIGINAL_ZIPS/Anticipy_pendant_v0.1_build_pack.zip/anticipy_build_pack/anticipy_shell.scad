// Anticipy pendant v0.1
// Locked assembled envelope: 51 x 21 x 11 mm
// Set part to "front", "back", or "assembled".

part = "assembled";
$fn = 96;

body_length = 45;
body_width = 21;
body_center_x = -3;
wall = 0.9;
front_depth = 6;
back_depth = 5;
floor = 0.8;

module capsule_2d(length, width, cx = 0) {
    radius = width / 2;
    hull() {
        translate([cx - (length - width) / 2, 0]) circle(r = radius);
        translate([cx + (length - width) / 2, 0]) circle(r = radius);
    }
}

module eyelet_2d() {
    difference() {
        translate([22, 0]) scale([3.5, 4.5]) circle(r = 1);
        translate([22, 0]) scale([1.6, 2.5]) circle(r = 1);
    }
}

module outside_2d() {
    union() {
        capsule_2d(body_length, body_width, body_center_x);
        eyelet_2d();
    }
}

module cavity_2d() {
    intersection() {
        offset(delta = -wall) capsule_2d(body_length, body_width, body_center_x);
        translate([-60, -30]) square([78, 60]);
    }
}

module tray(depth, is_front = false, add_tongue = false) {
    difference() {
        linear_extrude(depth) outside_2d();
        translate([0, 0, floor]) linear_extrude(depth + 1) cavity_2d();

        // Side-button opening at the seam.
        translate([-17, 10.2, depth - 1.1]) cube([5.4, 3.0, 2.4], center = true);

        if (is_front) {
            // Main microphone port and a small status-light aperture.
            translate([-13, 0, -0.2]) cylinder(h = floor + 0.5, r = 0.65);
            translate([6, 0, -0.2]) cylinder(h = floor + 0.5, r = 0.55);
        }
    }

    if (add_tongue) {
        translate([0, 0, depth]) linear_extrude(0.5)
            intersection() {
                difference() {
                    offset(delta = -1.05) capsule_2d(body_length, body_width, body_center_x);
                    offset(delta = -1.55) capsule_2d(body_length, body_width, body_center_x);
                }
                translate([-60, -30]) square([78, 60]);
            }
    }
}

module front_shell() {
    tray(front_depth, true, false);
}

module back_shell() {
    tray(back_depth, false, true);
}

if (part == "front") {
    front_shell();
} else if (part == "back") {
    back_shell();
} else {
    color([0.72, 0.73, 0.74]) front_shell();
    translate([0, 0, front_depth + back_depth]) rotate([180, 0, 0])
        color([0.12, 0.12, 0.13, 0.55]) back_shell();
}
