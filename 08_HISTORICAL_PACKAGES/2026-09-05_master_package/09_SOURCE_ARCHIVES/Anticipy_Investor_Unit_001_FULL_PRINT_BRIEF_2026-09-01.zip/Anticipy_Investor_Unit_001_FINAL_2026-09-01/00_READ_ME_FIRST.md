# Anticipy Unit 001 — read this first

> **STATUS: HOLD FOR PHYSICAL RELEASE TESTS**
>
> The CAD and firmware candidate are complete and reproducible. The physical
> investor unit is not released until the real printed shell, battery, motor, iPhone,
> charging, radio, audio, thermal, drop, and privacy gates in this packet pass.

## The simple version

The only owned Anticipy part is the XIAO board. Print the complete historical
body, hooked face, black 4.50 mm **PRIMARY_RENATA_ONLY M2 screw-retained** band,
two keyed retainer posts, body marking jig and safety bridge in black PETG. Put
the exact Renata 100640 battery and a gauged coin motor inside the audited
10.2 x 10.2 x 2.7 mm envelope on the insulated floor, put the bridge and a
**headerless XIAO
nRF52840 Sense** above the battery, then mechanically retain the band and close
the printed face. This primary closure does not depend on structural adhesive.

The finished nominal size is **51 x 22 x 14.5 mm**. There is no microSD board
and no onboard audio backlog in Unit 001. Audio streams live to the Anticipy
iPhone app. If the phone disconnects, that interval is not recorded.

CAD reports zero unintended modeled overlap across 1,424 checks against the
exact historical body and hooked face, including the face drop/slide path.
That authorizes printing and a dry fit; the real print and finished parts
remain the authority.

For the owner pickup list and complete hardware-guy instructions, open
`07_HANDOFF/Anticipy_Unit_001_Owner_Shopping_and_Hardware_Build_Brief.pdf`
first. The shorter `00_TUESDAY_WEDNESDAY_BUILD_CARD.md` is a backup summary.

## Print now

Open `01_CAD/README_BUILD.md`. Start with two complete body/face pairs, both
`PRIMARY_RENATA_ONLY_M2_screw_retained` band variants, the keyed posts, body
marking jig, safety bridge and exact-part gauges. Use black PETG or PETG-HF.
The nominal and loose bands are alternatives; use only the one that seats with
fingertip pressure.

## Tuesday, September 1

1. At 08:00 PT call Cadex. At 09:00 call Swiss Watch Parts and Vancouver
   Battery for exact **Renata ICP501022UPM / part 100640**. Ask each supplier
   to isolate 12 same-lot packs, sell one fit article, and hold 11 unpaid until
   Unit 001 passes. Record the staff name, physical count, and hold expiry.
2. Collect the emailed Lee hold so Unit 001 does not depend on DigiKey arriving:
   PID10431 motor, PID170433 NTR4101P, PID20011 BAS16, PID17426 10 kohm,
   PID160266 black PETG and PID6836 M2 x 10 screws. The Lee high-side circuit
   uses only the separately packaged **active-low** UF2. If DigiKey order
   101304421 is physically present, its Vybronics/AO3400A parts remain a valid
   alternative with the **active-high** UF2. Label the selected pair and never
   mix wiring or firmware.
3. Do not buy a battery or motor from its web description. Apply
   `03_PROCUREMENT/BATTERY_COUNTER_CARD.md` and the current/size gates.
4. Print two full body/face pairs plus the primary screw bands, posts, bridge,
   marking jig and gauges while calls are in progress. The first shell pair is
   sacrificial. For PRT-13853/DTP401525 inspection, print both
   `PLAN_B` gauges too, but that Plan B is incompatible with the primary
   Renata-only screw-retention hardware.
5. Verify the in-hand board says **XIAO nRF52840 Sense** and has no pin headers.
   The CAD does not fit an ESP32-S3 Sense or a headered XIAO.
6. The Memory Express SD-card order is not a Unit 001 dependency and is due at
   pickup. Do not collect it for this build without separate authorization.
7. With the empty sacrificial printed body, use the supplied jig to mark the two
   holes. Drill 2.2 mm preferred; a 3/32 inch (2.381 mm) bit is allowed. Never
   exceed 2.4 mm. Countersink only enough for a flush 90-degree screw head, then
   complete the empty-shell mechanical abuse gate before electronics enter.

## Wednesday, September 2

1. Select and label exactly one matched haptic pair: ordered DigiKey low-side
   circuit plus primary active-high UF2, or Lee high-side P-FET circuit plus the
   separate active-low fallback UF2. Full-erase one XIAO, flash only the matched
   candidate, and commission it to the intended test iPhone in a private room
   during its 120-second zero-bond window.
2. Prove app audio, haptic, reconnect, and second-phone rejection on USB power.
3. Measure every finished component, including the insulated driver island and
   battery lead route. Dry-fit the complete unpowered stack with witness film.
4. Build exactly as `04_ASSEMBLY/ASSEMBLY.md` specifies. Keep the cell
   disconnected until continuity, polarity, and current-limited checks pass.
5. Install the keyed posts and inspected countersunk screws without touching or
   loading the pouch. The printed face remains removable for powered open-case
   checks.
6. Run every line in `05_RELEASE/QA_RELEASE.md`. A failed line means HOLD,
   repair, and full retest.

## Thursday/Friday replication

Build no batch until Unit 001 passes unchanged. Then freeze the exact battery
lot, motor part, SMD driver packages, band variant, closure process, firmware
hash, and app version. Use adhesive only if deliberately selecting the
documented alternate closure. Build nine more units and retain two unassembled
spare kits, each with a release/inventory record. A substitution sends the
design back through Unit 001 qualification.

## Honest handoff language

A passed unit is a **functional investor sample in the final industrial-design
direction**. Say only what that serial-numbered unit proved: live app audio,
battery operation, charging, haptic, reconnect behaviour, two-hour closed-case
operation, and recorded mechanical tests. It is not yet certified,
waterproof, production-validated, or customer-sale-ready.
