# Tuesday/Wednesday Anticipy build card

> **UNIT 001 IS ON HOLD UNTIL EVERY PHYSICAL QA LINE PASSES.**

Starting inventory: **XIAO nRF52840 Sense boards only.** The shell, battery,
motor, driver and fasteners all come from the pickups/print files below.

## Tuesday: go here and get this

Battery calls first: ask Cadex, Swiss Watch Parts and Vancouver Battery for
**Renata ICP501022UPM / part 100640**. Buy **1** only after the label, finished
pack dimensions, polarity and exact datasheet/UN38.3 documents match this
packet; ask the supplier to hold **11 same-lot packs unpaid**. Do not accept a
“similar” battery.

At **Lee's Electronic Components, 4131 Fraser St, Vancouver** (604-875-1993,
Mon–Fri 09:00–17:30), collect the emailed hold and physically count:

| Quantity | Lee PID | Item | Listed price |
|---:|---:|---|---:|
| 1 | 160266 | Matter3D black PETG, 1.75 mm, 1 kg | C$35.00 |
| 12 | 10431 | sealed 3 V coin motor, 10 x 2.7 mm | C$4.10 each |
| 12 | 170433 | NTR4101P P-channel SOT-23 MOSFET | C$1.00 each |
| 3 packs | 20011 | BAS16 SOT-23, 5 per pack | C$2.50/pack |
| 1 pack | 17426 | 10 kohm 0603, 20 per pack | C$1.25/pack |
| 3 packs | 6836 | M2 x 10 flat countersunk, 10 per pack | C$1.20/pack listed |

The hardware builder has the required printer, soldering and measurement
equipment. Do not make a separate tool-store trip.
M2x10 PID6836 is the primary CAD length. If it is unavailable, M2x8 PID6748
(listed C$1.50/pack) is a fallback accepted only after the actual stack clamps
without bottoming or loss of engagement. Web counts are not a reservation:
call, get staff name/physical count/hold expiry, then travel.

The Lee motor/driver parts are the frozen all-local Unit 001 build path and fit
the audited mechanical motor envelope after the received motor passes the
supplied gauge. Do not mix in a different motor circuit or firmware. Ask the
hardware builder whether fine wire, solder/flux, <=0.05 mm insulation film,
thin electronics-safe adhesive and acoustic mesh are already in his bench kit;
buy only a missing consumable. microSD is not needed.

## Wednesday: tell the hardware guy these five things

1. **Print and drill empty parts.** Print two complete body/face pairs, the two
   `PRIMARY_RENATA_ONLY_M2_screw_retained` band variants, two keyed posts, body
   marking jig, safety bridge and gauges. On an empty sacrificial printed body, drill
   2.2 mm preferred or 3/32 inch allowed; never exceed 2.4 mm. Countersink only
   until the 90-degree head is flush; pass the empty-body abuse test.
2. **Use the frozen local electronics pair.** Lee NTR4101P high-side circuit
   + active-low UF2 SHA-256
   `54b12eefb226d886ae374043ad2e5e409f5301956940de8bb13f76d084d14299`.
   Never mix in the DigiKey active-high wiring or UF2 file.
3. **Prove it open.** Full-erase the headerless XIAO nRF52840 Sense, flash the
   matched UF2, privately commission the iPhone, then prove audio, haptic,
   reconnect, second-phone rejection and motor-off behavior on USB/bench power.
4. **Measure, wire and dry-fit.** Verify the exact Renata pack, all pinouts and
   polarity; gauge every finished part; current-limit first power; require
   combined board+motor <=160 mA peak and <=80 mA continuous for the Lee/Renata
   path, with no reset/heat. Close with witness film and zero pouch loading.
5. **Screw, test, release or hold.** Fit the keyed posts and inspected screws
   with no inward sharp end, then complete every line in
   `05_RELEASE/QA_RELEASE.md`. Only an all-green signed record releases Unit 001;
   one failed line means repair and full retest.
