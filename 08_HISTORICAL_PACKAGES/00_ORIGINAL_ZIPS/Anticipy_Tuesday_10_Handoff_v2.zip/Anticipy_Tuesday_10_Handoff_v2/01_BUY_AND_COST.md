# BUY THIS — AND NOTHING ELSE

Build **12** so the best **10** can be delivered.

## Cart 1 — DigiKey Canada

Upload `engineering/Anticipy_Tuesday_EVT_v0.1/BUY_12.csv` or order the exact MPNs in it.

- Current stocked subtotal: about **CAD 453.49 before tax**.
- Expected after BC tax: about **CAD 507.91**.
- Pay only if checkout shows delivery no later than Tuesday, September 1.

## Cart 2 — local memory

- Twelve 32 GB UHS-I U1-or-better microSD cards.
- Budget after tax: **CAD 188.03**.
- Reserve before driving; the currently indexed Vancouver-area stock is split among stores.

## Cart 3 — shell supplies

- One spool of genuine polycarbonate filament: about **CAD 38.07 after tax**.
- One small sheet of 0.025 in (0.635 mm) 5052-H32 aluminum, preferably pre-anodized satin silver. Call Metal Supermarkets Burnaby at 604-293-1231 Saturday 9–3; its live site lists 0.025 in 5052 and same-day small-quantity service. **Price and local stock still need phone confirmation.** Allow CAD 25–50.
- PET insulation, thin Poron/EVA, 3M 468MP/300LSE-type adhesive, fine wire and solder: allow **CAD 33.60**.

## Cart 4 — battery: STOP AND CHECK

Needed: protected 502025 LiPo, 200 mAh, finished pack at most 25 × 20 × 5 mm.

Do not pay unless the listing or seller confirms all four:

1. Integrated protection PCB.
2. Finished pack no larger than 25 × 20 × 5 mm, including protection board and wrap.
3. Arrival no later than Tuesday.
4. Correct JST polarity, or the builder will safely replace the connector before connection.

Budget after tax: **CAD 169.55** for enough candidate cells to bin 12. This exact Tuesday supply is not yet verified.

## Real total

| Route | Realistic total |
|---|---:|
| Anticipy manually prints, cuts, solders and tests all units | **about CAD 970–1,000** |
| Anticipy assembles; MakerLabs precision-cuts the faces | **about CAD 1,300–1,500** |
| Local shop owns the entire rush build | **about CAD 2,500–5,000** |

The CAD 970–1,000 route contains essentially no paid labour and requires Anticipy to hand-finish the aluminum accurately. MakerLabs' published same-day metal-laser minimum is CAD 300 before deburring. A one-stop shop cannot honestly supply parts, metal work, assembly and testing for CAD 1,000.
