# Anticipy cosmetic finish handoff

Use `ANTICIPY_wordmark_13mm_outlined.svg` for laser marking. Do not substitute a font at the shop.

- Final wordmark width: **13.00 mm**.
- Place it horizontally centered on the front face, **27.5 mm below the top edge** when the chain hole is at the top.
- Keep the logo on the aluminum section. Never mark, foil, or use conductive metallic paint on the polycarbonate RF nose.
- Follow `Anticipy_Cosmetic_Finish_Spec_v1.pdf` for color, grain, seam, button, edge and rejection criteria.

The finish package does not change the finished envelope: **56.0 x 23.0 x 12.0 mm**.
