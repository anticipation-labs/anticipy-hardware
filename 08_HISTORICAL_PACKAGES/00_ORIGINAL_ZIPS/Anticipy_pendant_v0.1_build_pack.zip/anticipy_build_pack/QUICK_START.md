# Anticipy pendant: do this now

## Today

1. Buy **two of every priority-1 item** in `order_sheet.csv`.
2. Send `front_shell.stl` and `back_shell.stl` to **Forge Labs or Ember Prototypes** and ask for two rush tough-resin sets.
3. Send `front_shell.stl` to **Protolabs** for a rush 6061-T6 aluminum quote. Do not wait for it before building the resin unit.

## When the parts arrive

1. Put the thin battery under the XIAO.
2. Put the round haptic motor in the top end.
3. Put the button in the side opening.
4. Solder exactly as shown in `README.md`.
5. Close the removable rear shell and add a light chain through the eyelet.

## What must be true on September 3

- It is no bigger than **51 × 21 × 11 mm**.
- It is no heavier than **17.4 g** without the chain.
- It records and sends audio to the iPhone.
- The button stops listening.
- The motor buzzes.
- It runs at least six hours on the 100 mAh test battery.

The first delivered unit can use a silver-finished resin front. Replace only the front with CNC aluminum when it arrives.
