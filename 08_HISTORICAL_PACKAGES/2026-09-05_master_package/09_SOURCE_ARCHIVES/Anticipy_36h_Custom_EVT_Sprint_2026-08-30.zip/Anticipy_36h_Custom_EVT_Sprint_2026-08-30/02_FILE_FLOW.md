# Anticipy file flow

## What goes where

| Recipient | Send now | What they create | Send later |
|---|---|---|---|
| Prime engineering lead | Entire engineering source ZIP | Reviewed PCB, battery decision, firmware, full PCBA STEP, release package | Everything needed by factory and mechanical lead |
| CCI Canadian Circuits | Capability RFQ and preliminary specifications only | Written DFM, stack-up, quote, boards, two first PCBAs | Released Gerber/drill/BOM/CPL/drawings/STEP/test package |
| Mechanical CAD lead | Requirements now; later complete PCBA STEP and battery STEP | Centre STEP/3MF, face DXFs/PDFs, assembly drawing | Final files to printer, metal shop, and integrator |
| MakerLabs | Capability RFQ now | Aluminum faces and marking | Final DXF/vector PDF after mechanical freeze |
| Firmware lead | KiCad schematic, pin map, requirements | Source, factory binary, app firmware, hashes, flash/test instructions | Binary and programming package to bring-up owner/factory |
| Final integrator | Planning SOP now | Complete sealed pendant and build record | Released PCBA, enclosure parts, battery, motor, firmware, test plan |

## Meaning of the factory files

| File | Meaning |
|---|---|
| `.kicad_sch` | Editable circuit diagram: what connects to what |
| `.kicad_pcb` | Editable physical board: where parts and copper go |
| Gerbers | Images of each board manufacturing layer |
| Drill files | Hole locations and sizes |
| IPC-356 | Electrical netlist used to verify the fabricated board |
| BOM | Bill of materials: exact manufacturer shopping list |
| CPL / pick-and-place | Robot coordinates and component rotations |
| Assembly drawing | Human orientation and process reference |
| Fab drawing / stack-up | Board material, thickness, copper layers, finish, and tolerances |
| PCBA STEP | 3D model of the fully populated electronics assembly |
| Enclosure STEP | Editable 3D enclosure geometry |
| 3MF | Polycarbonate centre ready for a controlled 3D-print process |
| DXF / vector PDF | Two-dimensional cut paths for aluminum faces |
| Firmware `.hex`/`.bin` | Software flashed into the board |
| SHA-256 checksums | Proof that every recipient has identical released bytes |

## Definition of “done”

“Done” is not a Gerber ZIP and it is not a visually complete shell. It is one
serialized pendant that passes the released electrical, firmware, acoustic,
radio, charging, thermal, storage, runtime, haptic, button, light, rattle,
insulation, and mechanical tests, with the other ten PCBAs still held until the
first two pass.

