# Active-low fallback build and static-test evidence

Status: **HOLD FOR PHYSICAL APP/HARDWARE RELEASE TESTS**.

## Reproducible artifact

- Artifact size: 528,384 bytes
- Artifact SHA-256: `54b12eefb226d886ae374043ad2e5e409f5301956940de8bb13f76d084d14299`
- Clean builds: `local_pfet_active_low_a` and `local_pfet_active_low_b`
- Both clean-build UF2 hashes: `54b12eefb226d886ae374043ad2e5e409f5301956940de8bb13f76d084d14299`
- Both generated DTS hashes: `474b4aa33bc2615ef69d4ba97a9556733ad5e5d001d3b19916096a05b96f4341`
- NCS v2.7.0 commit `5cb85570ca43`
- Zephyr commit `100befc70c74`
- Zephyr SDK 0.16.5; `arm-zephyr-eabi-gcc` 12.2.0

Two pristine source copies were built independently for
`xiao_ble/nrf52840/sense` with the packaged base and extra configuration. Their
UF2 files are byte-identical. The packaged `host_checks.py` and
`owner_lock_host_checks.py` both pass against the modified copy.

## Polarity evidence

The exact and only source delta is `SOURCE_DIFF.patch`: D0 changes from
`GPIO_ACTIVE_HIGH` to `GPIO_ACTIVE_LOW`. The generated devicetree contains:

```text
gpios = < &gpio0 0x2 0x1 >;
```

and the generated header records pin `2`, flags `1`. No application C source,
configuration, Bluetooth behavior, charging target or owner-lock logic changed.

## Boundary

Static checks and byte-identical builds do not prove the Lee motor identity,
P-FET/diode pinout, boot-state safety, current, thermal, audio, RF, battery or
closed-shell behavior. Those remain physical release gates. This artifact is
incompatible with the primary active-high AO3400A/NMOS circuit.
