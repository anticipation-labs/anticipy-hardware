import Foundation

/// Saves each live Opus packet as [uint16 little-endian length][packet bytes].
/// This is a transport proof and debugging archive, not a playable audio file.
final class OpusFrameArchive {
    private let url: URL
    private let queue = DispatchQueue(label: "ai.anticipy.tuesday.live-archive")

    init(url: URL) {
        self.url = url
    }

    func append(_ frame: Data) {
        guard !frame.isEmpty, frame.count <= Int(UInt16.max) else { return }
        queue.async { [url] in
            if !FileManager.default.fileExists(atPath: url.path) {
                FileManager.default.createFile(atPath: url.path, contents: nil)
            }
            guard let handle = try? FileHandle(forWritingTo: url) else { return }
            defer { try? handle.close() }
            do {
                try handle.seekToEnd()
                let length = UInt16(frame.count)
                try handle.write(contentsOf: Data([
                    UInt8(length & 0xff),
                    UInt8((length >> 8) & 0xff),
                ]))
                try handle.write(contentsOf: frame)
            } catch {
                return
            }
        }
    }
}
