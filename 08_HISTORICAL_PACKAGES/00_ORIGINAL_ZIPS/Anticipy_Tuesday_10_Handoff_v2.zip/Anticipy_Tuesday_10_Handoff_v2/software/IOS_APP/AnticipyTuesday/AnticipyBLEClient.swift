import CoreBluetooth
import Foundation

struct AnticipyPendant: Identifiable, Equatable {
    let id: UUID
    let name: String
    let rssi: Int
}

/// Minimal CoreBluetooth transport for the Anticipy founder-EVT firmware.
///
/// This file deliberately stops at raw Opus frames. Feed each frame separately
/// to Anticipy's streaming endpoint or to a libopus decoder configured for
/// 16 kHz, mono, 160 samples (10 ms) per frame.
final class AnticipyBLEClient: NSObject {
    static let audioService = CBUUID(string: "19B10000-E8F2-537E-4F6C-D104768A1214")
    static let audioData = CBUUID(string: "19B10001-E8F2-537E-4F6C-D104768A1214")
    static let audioCodec = CBUUID(string: "19B10002-E8F2-537E-4F6C-D104768A1214")

    static let storageService = CBUUID(string: "30295780-4301-EABD-2904-2849ADFEAE43")
    static let storageCommand = CBUUID(string: "30295781-4301-EABD-2904-2849ADFEAE43")
    static let storageStatus = CBUUID(string: "30295782-4301-EABD-2904-2849ADFEAE43")

    static let buttonService = CBUUID(string: "23BA7924-0000-1000-7450-346EAC492E92")
    static let buttonData = CBUUID(string: "23BA7925-0000-1000-7450-346EAC492E92")

    static let hapticService = CBUUID(string: "CAB1AB95-2EA5-4F4D-BB56-874B72CFC984")
    static let hapticCommand = CBUUID(string: "CAB1AB96-2EA5-4F4D-BB56-874B72CFC984")

    static let sdRecordBytes = 440

    var onState: ((String) -> Void)?
    var onError: ((String) -> Void)?
    var onLiveOpusFrame: ((Data) -> Void)?
    var onBacklogOpusFrame: ((Data) -> Void)?
    var onBacklogProgress: ((_ committedBytes: UInt32, _ totalBytes: UInt32) -> Void)?
    var onBacklogTotal: ((UInt32) -> Void)?
    var onButton: ((UInt8) -> Void)?
    var onDevices: (([AnticipyPendant]) -> Void)?
    var onConnection: ((_ connected: Bool, _ id: UUID?) -> Void)?
    var onReady: (() -> Void)?

    private static let selectedPeripheralKey = "anticipy.selectedPeripheral"
    private let bluetoothQueue = DispatchQueue(label: "ai.anticipy.tuesday.bluetooth")
    private lazy var central = CBCentralManager(
        delegate: self,
        queue: bluetoothQueue,
        options: [CBCentralManagerOptionRestoreIdentifierKey: "ai.anticipy.tuesday.central"]
    )
    private var peripheral: CBPeripheral?
    private var discovered: [UUID: (peripheral: CBPeripheral, rssi: Int)] = [:]
    private var selectedPeripheralID: UUID?
    private var shouldReconnect = true
    private var audioDataCharacteristic: CBCharacteristic?
    private var codecCharacteristic: CBCharacteristic?
    private var storageCommandCharacteristic: CBCharacteristic?
    private var storageStatusCharacteristic: CBCharacteristic?
    private var hapticCharacteristic: CBCharacteristic?

    private var storageNotificationsReady = false
    private var pendingBackfill = false
    private var backlogBuffer = Data()
    private var backlogTotal: UInt32 = 0
    private var committedOffset: UInt32 = 0
    private var sinkURL: URL?
    private var sinkHandle: FileHandle?

    private var liveFrameID: UInt16?
    private var liveExpectedFragment: UInt8 = 0
    private var liveFrame = Data()

    override init() {
        if let saved = UserDefaults.standard.string(forKey: Self.selectedPeripheralKey) {
            selectedPeripheralID = UUID(uuidString: saved)
        }
        super.init()
        _ = central
    }

    deinit {
        try? sinkHandle?.close()
    }

    func start() {
        bluetoothQueue.async { [weak self] in
            self?.startOnBluetoothQueue()
        }
    }

    private func startOnBluetoothQueue() {
        guard central.state == .poweredOn else {
            onState?("Waiting for Bluetooth")
            return
        }
        shouldReconnect = true

        if let selectedPeripheralID,
           let known = central.retrievePeripherals(withIdentifiers: [selectedPeripheralID]).first {
            peripheral = known
            known.delegate = self
            central.connect(known, options: nil)
            onState?("Reconnecting to saved Anticipy")
            return
        }

        central.stopScan()
        central.scanForPeripherals(withServices: [Self.audioService], options: [
            CBCentralManagerScanOptionAllowDuplicatesKey: false,
        ])
        onState?(selectedPeripheralID == nil ? "Choose your Anticipy" : "Looking for saved Anticipy")
    }

    func stop() {
        bluetoothQueue.async { [weak self] in
            guard let self else { return }
            pendingBackfill = false
            shouldReconnect = false
            if let peripheral {
                central.cancelPeripheralConnection(peripheral)
            }
            central.stopScan()
        }
    }

    func scan() {
        bluetoothQueue.async { [weak self] in
            guard let self else { return }
            discovered.removeAll()
            emitDevices()
            startOnBluetoothQueue()
        }
    }

    func connect(to id: UUID) {
        bluetoothQueue.async { [weak self] in
            guard let self else { return }
            shouldReconnect = true
            selectedPeripheralID = id
            UserDefaults.standard.set(id.uuidString, forKey: Self.selectedPeripheralKey)
            central.stopScan()

            let target = discovered[id]?.peripheral ?? central.retrievePeripherals(withIdentifiers: [id]).first
            guard let target else {
                startOnBluetoothQueue()
                return
            }
            peripheral = target
            target.delegate = self
            central.connect(target, options: nil)
            onState?("Connecting to \(target.name ?? "Anticipy")")
        }
    }

    func forgetSelectedPendant() {
        bluetoothQueue.async { [weak self] in
            guard let self else { return }
            shouldReconnect = false
            pendingBackfill = false
            if let peripheral {
                central.cancelPeripheralConnection(peripheral)
            }
            peripheral = nil
            selectedPeripheralID = nil
            UserDefaults.standard.removeObject(forKey: Self.selectedPeripheralKey)
            clearCharacteristics()
            onConnection?(false, nil)
            shouldReconnect = true
            startOnBluetoothQueue()
        }
    }

    /// The sink is raw concatenated 440-byte SD records. It is fsynced before
    /// committedOffset advances, which makes reconnect/resume crash-safe at a
    /// record boundary.
    func setBacklogSink(_ url: URL) throws {
        try sinkHandle?.close()
        sinkHandle = nil
        sinkURL = url

        try FileManager.default.createDirectory(
            at: url.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        if !FileManager.default.fileExists(atPath: url.path) {
            guard FileManager.default.createFile(atPath: url.path, contents: nil) else {
                throw ClientError.cannotCreateSink
            }
        }

        let handle = try FileHandle(forUpdating: url)
        let size = try handle.seekToEnd()
        let completeSize = size - (size % UInt64(Self.sdRecordBytes))
        if completeSize != size {
            try handle.truncate(atOffset: completeSize)
        }
        guard completeSize <= UInt64(UInt32.max) else {
            throw ClientError.sinkTooLarge
        }
        committedOffset = UInt32(completeSize)
        sinkHandle = handle
    }

    /// Subscribe first, read the device's current file size, then request bytes
    /// from the last locally fsynced 440-byte boundary.
    func requestBackfill() {
        bluetoothQueue.async { [weak self] in
            guard let self else { return }
            requestBackfillOnBluetoothQueue()
        }
    }

    private func requestBackfillOnBluetoothQueue() {
        guard sinkHandle != nil else {
            onError?("Backlog file is unavailable")
            return
        }
        pendingBackfill = true
        guard let peripheral, let status = storageStatusCharacteristic else {
            onState?("Backfill queued until storage is discovered")
            return
        }
        peripheral.readValue(for: status)
    }

    func stopBackfill() {
        bluetoothQueue.async { [weak self] in
            self?.pendingBackfill = false
            self?.writeStorageCommand(command: 3, file: 1, offset: 0)
        }
    }

    func playHaptic(level: UInt8) {
        bluetoothQueue.async { [weak self] in
            guard let self, (1...3).contains(level), let peripheral, let hapticCharacteristic else {
                return
            }
            peripheral.writeValue(Data([level]), for: hapticCharacteristic, type: .withResponse)
        }
    }

    private func emitDevices() {
        let devices = discovered.map { entry in
            AnticipyPendant(
                id: entry.key,
                name: entry.value.peripheral.name ?? "Anticipy Founder",
                rssi: entry.value.rssi
            )
        }.sorted { $0.rssi > $1.rssi }
        onDevices?(devices)
    }

    private func clearCharacteristics() {
        audioDataCharacteristic = nil
        codecCharacteristic = nil
        storageCommandCharacteristic = nil
        storageStatusCharacteristic = nil
        hapticCharacteristic = nil
        storageNotificationsReady = false
        backlogBuffer.removeAll(keepingCapacity: true)
        flushLiveFrame()
    }

    private func beginBackfillIfReady() {
        guard pendingBackfill, storageNotificationsReady else { return }
        guard backlogTotal > 0 else {
            pendingBackfill = false
            onState?("No offline audio")
            return
        }
        if committedOffset > backlogTotal {
            do {
                try sinkHandle?.truncate(atOffset: 0)
                try sinkHandle?.seek(toOffset: 0)
                committedOffset = 0
            } catch {
                onError?("Could not reset stale backlog sink: \(error)")
                return
            }
        }
        backlogBuffer.removeAll(keepingCapacity: true)
        writeStorageCommand(command: 0, file: 1, offset: committedOffset)
        onState?("Backfill requested at byte \(committedOffset)")
    }

    private func writeStorageCommand(command: UInt8, file: UInt8, offset: UInt32) {
        guard let peripheral, let characteristic = storageCommandCharacteristic else { return }
        let commandBytes = Data([
            command,
            file,
            UInt8((offset >> 24) & 0xff),
            UInt8((offset >> 16) & 0xff),
            UInt8((offset >> 8) & 0xff),
            UInt8(offset & 0xff),
        ])
        peripheral.writeValue(commandBytes, for: characteristic, type: .withResponse)
    }

    private func consumeLiveNotification(_ data: Data) {
        guard data.count >= 4 else {
            onError?("Short live-audio notification")
            return
        }
        let id = UInt16(data[data.startIndex]) | (UInt16(data[data.startIndex + 1]) << 8)
        let fragment = data[data.startIndex + 2]
        let payload = data.dropFirst(3)

        if liveFrameID != id {
            flushLiveFrame()
            liveFrameID = id
            liveExpectedFragment = 0
        }
        guard fragment == liveExpectedFragment else {
            onError?("Dropped/out-of-order live fragment for frame \(id)")
            liveFrame.removeAll(keepingCapacity: true)
            liveFrameID = nil
            return
        }
        liveFrame.append(contentsOf: payload)
        liveExpectedFragment &+= 1

        // The founder build emits fixed 16-kb/s, 10-ms packets (~20 bytes) and
        // waits for ATT MTU >= 100, so every supported frame is fragment zero.
        // Keeping frame IDs above makes a future fragmented variant detectable.
        if fragment == 0 {
            flushLiveFrame()
        }
    }

    private func flushLiveFrame() {
        if !liveFrame.isEmpty {
            onLiveOpusFrame?(liveFrame)
        }
        liveFrame.removeAll(keepingCapacity: true)
        liveFrameID = nil
        liveExpectedFragment = 0
    }

    private func consumeStorageNotification(_ data: Data) {
        guard !data.isEmpty else { return }
        if data.count == 1 {
            switch data[data.startIndex] {
            case 0:
                onState?("Backfill accepted")
            case 100:
                pendingBackfill = false
                if backlogBuffer.isEmpty {
                    onState?("Backfill complete")
                } else {
                    onError?("Backfill ended with an incomplete 440-byte record")
                }
            case 3: onError?("Backfill file number is invalid")
            case 4: onState?("No offline audio")
            case 5: onError?("Backfill offset is beyond the file")
            case 6: onError?("Backfill command is invalid")
            case 200: onState?("Offline audio deleted")
            default: onError?("Unknown storage status \(data[data.startIndex])")
            }
            return
        }

        backlogBuffer.append(data)
        while backlogBuffer.count >= Self.sdRecordBytes {
            let block = Data(backlogBuffer.prefix(Self.sdRecordBytes))
            backlogBuffer.removeFirst(Self.sdRecordBytes)
            do {
                try commitBacklogBlock(block)
            } catch {
                pendingBackfill = false
                stopBackfill()
                onError?("Could not persist backlog record: \(error)")
                return
            }
        }
    }

    private func commitBacklogBlock(_ block: Data) throws {
        guard block.count == Self.sdRecordBytes, let sinkHandle else {
            throw ClientError.badRecord
        }
        let frames = try Self.parseSDRecord(block)
        try sinkHandle.seek(toOffset: UInt64(committedOffset))
        try sinkHandle.write(contentsOf: block)
        try sinkHandle.synchronize()
        committedOffset += UInt32(Self.sdRecordBytes)
        for frame in frames {
            onBacklogOpusFrame?(frame)
        }
        onBacklogProgress?(committedOffset, backlogTotal)
    }

    static func parseSDRecord(_ block: Data) throws -> [Data] {
        guard block.count == sdRecordBytes else { throw ClientError.badRecord }
        var frames: [Data] = []
        var position = 0
        while position < block.count {
            let count = Int(block[block.startIndex + position])
            if count == 0 { break }
            let start = position + 1
            let end = start + count
            guard end <= block.count else { throw ClientError.badRecord }
            frames.append(block.subdata(in: start..<end))
            position = end
        }
        return frames
    }

    private static func littleEndianUInt32(_ data: Data, at offset: Int) -> UInt32 {
        UInt32(data[data.startIndex + offset]) |
            (UInt32(data[data.startIndex + offset + 1]) << 8) |
            (UInt32(data[data.startIndex + offset + 2]) << 16) |
            (UInt32(data[data.startIndex + offset + 3]) << 24)
    }

    enum ClientError: Error {
        case badRecord
        case cannotCreateSink
        case sinkTooLarge
    }
}

extension AnticipyBLEClient: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            startOnBluetoothQueue()
        } else {
            onState?("Bluetooth state: \(central.state.rawValue)")
        }
    }

    func centralManager(_ central: CBCentralManager, willRestoreState dict: [String: Any]) {
        let restored = dict[CBCentralManagerRestoredStatePeripheralsKey] as? [CBPeripheral] ?? []
        guard let restoredPeripheral = restored.first(where: { $0.identifier == selectedPeripheralID }) ?? restored.first else {
            return
        }
        peripheral = restoredPeripheral
        selectedPeripheralID = restoredPeripheral.identifier
        UserDefaults.standard.set(restoredPeripheral.identifier.uuidString, forKey: Self.selectedPeripheralKey)
        restoredPeripheral.delegate = self
        onState?("Restored Anticipy connection")
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        discovered[peripheral.identifier] = (peripheral, RSSI.intValue)
        emitDevices()

        guard peripheral.identifier == selectedPeripheralID else { return }
        central.stopScan()
        self.peripheral = peripheral
        peripheral.delegate = self
        central.connect(peripheral, options: nil)
        onState?("Connecting to \(peripheral.name ?? "Anticipy")")
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        central.stopScan()
        self.peripheral = peripheral
        selectedPeripheralID = peripheral.identifier
        UserDefaults.standard.set(peripheral.identifier.uuidString, forKey: Self.selectedPeripheralKey)
        peripheral.discoverServices([
            Self.audioService,
            Self.storageService,
            Self.buttonService,
            Self.hapticService,
        ])
        onConnection?(true, peripheral.identifier)
        onState?("Connected; discovering services")
    }

    func centralManager(
        _ central: CBCentralManager,
        didFailToConnect peripheral: CBPeripheral,
        error: Error?
    ) {
        onError?("Connect failed: \(error?.localizedDescription ?? "unknown")")
        onConnection?(false, peripheral.identifier)
        if shouldReconnect {
            bluetoothQueue.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                self?.startOnBluetoothQueue()
            }
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDisconnectPeripheral peripheral: CBPeripheral,
        error: Error?
    ) {
        clearCharacteristics()
        onConnection?(false, peripheral.identifier)
        onState?("Disconnected; looking again")
        if shouldReconnect, peripheral.identifier == selectedPeripheralID {
            bluetoothQueue.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                guard let self else { return }
                self.peripheral = peripheral
                peripheral.delegate = self
                central.connect(peripheral, options: nil)
            }
        } else if shouldReconnect {
            startOnBluetoothQueue()
        }
    }
}

extension AnticipyBLEClient: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error {
            onError?("Service discovery failed: \(error)")
            return
        }
        for service in peripheral.services ?? [] {
            switch service.uuid {
            case Self.audioService:
                peripheral.discoverCharacteristics([Self.audioData, Self.audioCodec], for: service)
            case Self.storageService:
                peripheral.discoverCharacteristics([Self.storageCommand, Self.storageStatus], for: service)
            case Self.buttonService:
                peripheral.discoverCharacteristics([Self.buttonData], for: service)
            case Self.hapticService:
                peripheral.discoverCharacteristics([Self.hapticCommand], for: service)
            default:
                break
            }
        }
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didDiscoverCharacteristicsFor service: CBService,
        error: Error?
    ) {
        if let error {
            onError?("Characteristic discovery failed: \(error)")
            return
        }
        for characteristic in service.characteristics ?? [] {
            switch characteristic.uuid {
            case Self.audioData:
                audioDataCharacteristic = characteristic
                peripheral.setNotifyValue(true, for: characteristic)
            case Self.audioCodec:
                codecCharacteristic = characteristic
                // This encrypted read asks iOS to establish the bonded link.
                peripheral.readValue(for: characteristic)
            case Self.storageCommand:
                storageCommandCharacteristic = characteristic
                peripheral.setNotifyValue(true, for: characteristic)
            case Self.storageStatus:
                storageStatusCharacteristic = characteristic
            case Self.buttonData:
                peripheral.setNotifyValue(true, for: characteristic)
            case Self.hapticCommand:
                hapticCharacteristic = characteristic
            default:
                break
            }
        }
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateNotificationStateFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            onError?("Notification setup failed for \(characteristic.uuid): \(error)")
            return
        }
        if characteristic.uuid == Self.storageCommand {
            storageNotificationsReady = characteristic.isNotifying
            if pendingBackfill, let status = storageStatusCharacteristic {
                peripheral.readValue(for: status)
            }
        }
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateValueFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            onError?("Read/notify failed for \(characteristic.uuid): \(error)")
            return
        }
        guard let data = characteristic.value else { return }
        switch characteristic.uuid {
        case Self.audioData:
            consumeLiveNotification(data)
        case Self.audioCodec:
            if data.first == 20 {
                onState?("Opus 16-kHz stream ready")
                onReady?()
            } else {
                onError?("Unexpected codec ID \(data.first.map { String($0) } ?? "none")")
            }
        case Self.storageStatus:
            guard data.count >= 8 else {
                onError?("Short storage status")
                return
            }
            backlogTotal = Self.littleEndianUInt32(data, at: 0)
            onBacklogTotal?(backlogTotal)
            beginBackfillIfReady()
        case Self.storageCommand:
            consumeStorageNotification(data)
        case Self.buttonData:
            if let event = data.first { onButton?(event) }
        default:
            break
        }
    }
}
