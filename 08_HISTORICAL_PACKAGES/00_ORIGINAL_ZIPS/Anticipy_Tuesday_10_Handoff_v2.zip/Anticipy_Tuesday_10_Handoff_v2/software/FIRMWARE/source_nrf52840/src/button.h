#ifndef BUTTON_H
#define BUTTON_H

#include <stdbool.h>

typedef enum { IDLE, GRACE } FSM_STATE_T;

int button_init();
/**
 * Return true only when the button is already held at boot and remains held
 * continuously for eight seconds. This is deliberately separate from the
 * normal three-second power-off gesture.
 */
bool button_factory_reset_requested_at_boot(void);
void activate_button_work();
void register_button_service();
void turnoff_all();
FSM_STATE_T get_current_button_state();

void force_button_state(FSM_STATE_T state);

#endif
