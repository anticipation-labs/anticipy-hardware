# ANTICIPY — TUESDAY BUILD ORDER

## Deliverable

- Quantity: **10 matching working pendants**; build 12 to allow two failures.
- Pickup: **Tuesday, September 1, 2026, Vancouver**.
- Finished envelope: **56.0 × 23.0 × 12.0 mm**. Never scale the CAD.
- Construction: component-built Anticipy electronics. No finished PLAUD device or other recorder may be relabelled.

## Exterior — copy this exactly

- Shape: slim rounded silver pill shown in the supplied CAD and appearance reference.
- Structure and RF nose: genuine **polycarbonate**.
- Cosmetic faces: **0.60–0.65 mm 5052-H32 aluminum**.
- Aluminum finish: fine straight brush in the long direction; pale neutral silver; no visible mill marks, burrs, glue, or fingerprints.
- Polycarbonate RF nose: opaque non-metallic satin silver, visually matched to the aluminum. Never apply metal foil or conductive/metal-filled paint over it.
- The aluminum/PC division is a precision hairline, not a black stripe. Target gap 0.12 mm; reject above 0.25 mm.
- All face pieces coplanar within 0.10 mm. Edge mismatch or steps are an automatic reject.
- Mark: small centered **ANTICIPY** wordmark from the supplied vector. Laser mark only the aluminum; do not engrave through the face.
- Visible controls: one flush circular button and one tiny white status light. No screws or green circuit board visible.

## Build sequence

1. Print and finish **one** polycarbonate body, bridge, RF face pair, and all three button plungers.
2. Cut and finish **one** aluminum face pair.
3. Measure the protected cell. Stop unless the finished pack is at most 25 × 20 × 5 mm, has an integral protection PCB, intact pouch, documented capacity, and correct connector polarity.
4. Flash and bench-test one electronics stack before installing it.
5. Dry-fit unit 1. Nothing may touch, pinch, puncture, or compress the pouch cell.
6. Prove unit 1 charges, pairs, records, stores offline audio, reconnects, backfills, operates its button/haptic/LED, and factory-resets.
7. Shake and inspect unit 1. There must be no rattle, sharp edge, adhesive squeeze-out, face step, or visible print layer.
8. Only after unit 1 passes, duplicate the remaining 11 and select the best 10.

## Per-unit acceptance gate

- Size passes a 56.1 × 23.1 × 12.1 mm go/no-go box.
- USB charging works and the cell does not become hot, swell, or move.
- Fresh iPhone can pair after the factory-reset gesture.
- Ten-minute live recording and ten-minute offline recording both transfer successfully.
- Button, vibration, light, microphone, SD storage, and reconnect all pass.
- No rattle after vigorous hand shake; no opening after a 0.75 m drop onto plywood.
- Exterior is investor-clean under bright desk light.

## Stop conditions

- Do not install an unprotected, swollen, undocumented, or oversize cell.
- Do not close a unit that presses on the battery.
- Do not cover the RF nose with metal or metallic coating.
- Do not promise 16-hour runtime, encrypted storage, or customer distribution until those tests and release gates pass.

## Files to use

- `engineering/Anticipy_Tuesday_EVT_v0.1/` — exact CAD, print plates, aluminum templates, BOM, and firmware lab build.
- `appearance/ANTICIPY_LASER_MARK.svg` — production wordmark geometry.
- `appearance/ANTICIPY_FINISH_SPEC.md` — cosmetic inspection details.
- `software/` — Tuesday iPhone/firmware package when present.

