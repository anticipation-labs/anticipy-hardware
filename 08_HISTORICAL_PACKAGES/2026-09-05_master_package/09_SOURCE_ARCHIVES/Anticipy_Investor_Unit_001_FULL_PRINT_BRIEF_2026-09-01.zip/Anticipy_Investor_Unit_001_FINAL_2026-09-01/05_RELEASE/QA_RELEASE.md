# Unit 001 investor release record

Serial: __________  Builder: __________  Date/time PT: __________

Every line is initialled with evidence. One red line means **HOLD**.

## Identity and traceability

- [ ] Board visually verified: headerless XIAO nRF52840 Sense.
- [ ] Full internal erase completed before commissioning; reused external QSPI
      was sanitized or board is documented new.
- [ ] Haptic hardware/firmware pair is selected and physically labelled:
      **DigiKey active-high / Lee NTR4101P active-low**; no mixed parts: ______
- [ ] Firmware filename and SHA-256 match that selected pair: ______________
- [ ] Anticipy TestFlight/app version recorded: _____________________________
- [ ] Battery manufacturer/MPN/lot and archived documents recorded: _________
- [ ] Motor and driver exact parts/packages recorded; ordered target is
      Vybronics VCLP1020B002L + AO3400A/1N4148W-HF/100 ohm/100 kohm: _______
- [ ] Primary Renata-only screw band, post variant, print settings, filament
      lot, screw PID/length/finish and builder recorded. If an alternate bonded
      closure was deliberately used, its adhesive lot/TDS/cure is also recorded.

## Mechanical/electrical

- [ ] Actual shell, XIAO, pack body, lead route, motor, and finished insulated
      8 x 4 x 2 mm driver island pass their gauges.
- [ ] No exposed conductor, flux, sharp edge, loose hard part, or wire pinch.
- [ ] No hard part, joint, lead, or wire loads the pouch; witness film clean.
- [ ] Face drops/slides/closes with fingertip pressure; USB does not move PCB.
- [ ] Motor is sealed and securely bonded; exact envelope gauge,
      current/current margin
      and flyback polarity are recorded.
- [ ] Empty sacrificial body passed marking/drilling/countersinking first; body
      holes are 2.2–2.4 mm, 90-degree heads are flush, screw stack clamps without
      bottoming, and no end contacts pouch/wire/hooks.
- [ ] Empty screw-retained shell passed six-direction drop, shake/twist and
      20 open/close cycles. If alternate adhesive was used, its coupon and fully
      cured seam also passed the documented gate.

## Firmware, app, and privacy

- [ ] Release profile is **LIVE-STREAM ONLY**. No microSD/QSPI backlog exists.
- [ ] Phone A commissions in private, pairs, receives intelligible audio, and
      controls haptic. Pairing completed and settings were given >2 s to store.
- [ ] After power cycle, Phone A reconnects 20/20.
- [ ] Phone B cannot connect/read audio/issue haptic while Phone A owns unit.
- [ ] If D7 is fitted: 10 s boot hold clears owner, then Phone B can commission.
      If omitted: controlled SWD erase/recovery path was rehearsed and recorded.
- [ ] App clearly reports a disconnect and resumes live audio without claiming
      the missing interval was captured.
- [ ] App-triggered DFU is owner-gated. No claim of signed/secure boot or secure
      owner-only OTA is made.

## Functional and power

- [ ] Cold boot on qualified battery: 10/10.
- [ ] Worst battery-branch charge current from USB insertion through bootloader,
      application, termination, and recharge recorded: ______ mA; inside exact
      pack limit with margin.
- [ ] Charge from 20–30% to at least 80% with no reset, pouch change, or abnormal
      heat; polarity/current log attached.
- [ ] Intelligible closed-case live audio runs 60 continuous minutes.
- [ ] Haptic short/medium/long: 25 each, with no reset, mic noise, RF loss, heat,
      or mechanical movement.
- [ ] For Lee/Renata fallback only: combined board-plus-motor draw is
      ______ mA peak and ______ mA continuous; both are <=160/80 mA, with no
      reset or heat.
- [ ] Button events 50/50 if fitted.
- [ ] Closed-case BLE range passes at 5 m and 10 m in the intended orientation,
      including body-worn test; result: ____________________.
- [ ] Two-hour combined audio/BLE/haptic soak passes; shell/cell rise <10 C.
- [ ] Battery percentage is plausible at full/mid/low; measured operating time
      demonstrated for this release: ______ hours.
- [ ] System-off/wake and watchdog recovery pass.

## Mechanical abuse and finish

- [ ] Six-direction 1 m drop onto plywood over concrete, powered off; seam stays
      closed and no pouch damage/loose part occurs; all functions pass afterward.
- [ ] 100 firm hand shakes and moderate hand twist: no rattle, creep, crack,
      opening, or reset.
- [ ] Normal USB side-load does not move board or damage seam.
- [ ] Reopened after abuse: pouch has no mark, dent, crease, rub, or lead strain.
- [ ] Reclosed and repeated 15-minute audio/reconnect/haptic test.
- [ ] Exterior is clean and product-like; no adhesive bloom, tool marks,
      misaligned seam, raw hole, or visible print defect.

## Handoff

- [ ] Intended recipient/account is provisioned; support and recovery contact
      included.
- [ ] Recipient is told this is a functional production-intent investor sample,
      not certified, waterproof, production-validated, or customer-sale-ready.
- [ ] Transport follows current carrier rules for lithium battery contained in
      equipment; exact UN38.3 summary travels with the build record.

Decision: **PASS / HOLD**

Released by: ____________________  Time: ____________________
