import SwiftUI

@main
struct AnticipyTuesdayApp: App {
    @StateObject private var model = PendantViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
        }
    }
}
