# LOCAL BUILDER

## Primary — one-shop route

**Unlimited Design Ltd., Burnaby**  
604-830-9829  
info@unlimiteddesignltd.com  
#110 — 4288 Lozells Avenue, Burnaby, BC

Why: its published services combine CAD, CNC metal/plastic work, electronics integration, laser engraving, hand fabrication and small time-critical prototypes.

Ask for one named senior builder to own unit 1 and the ten-unit duplication. Do not pay a rush deposit until the written quote states quantity, materials, envelope, acceptance tests and Tuesday pickup time.

Realistic planning allowance: **CAD 1,500–4,000 rush labour/fabrication, plus about CAD 950 parts**. This is an informed planning range, not their quote.

## Metal-only backup

**MakerLabs, Vancouver**  
778-984-7299  
hello@makerlabs.com  
780 East Cordova Street, Vancouver, BC  
Open daily 12–9 pm according to its current site.

Request: same-day cutting/deburring/marking of 20 nested 0.635 mm brushed 5052-H32 face pieces from the supplied CAD/vector, with grain along the long axis and Tuesday pickup.

Published minimums imply about **CAD 475–500** for same-day cutting plus 30 minutes of metal finishing. MakerLabs is not the electronics assembler.

