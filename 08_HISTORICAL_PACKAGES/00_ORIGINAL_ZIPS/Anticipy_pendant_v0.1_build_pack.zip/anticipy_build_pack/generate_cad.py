#!/usr/bin/env python3
"""Generate printable STL shells, a fit-check GLB, and a dimensioned layout."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import trimesh
from shapely import affinity
from shapely.geometry import LineString, Point, box
from shapely.ops import unary_union


ROOT = Path(__file__).resolve().parent
BODY_LENGTH = 45.0
BODY_WIDTH = 21.0
BODY_CENTER_X = -3.0
WALL = 0.9
FLOOR = 0.8
FRONT_DEPTH = 6.0
BACK_DEPTH = 5.0


def capsule(length=BODY_LENGTH, width=BODY_WIDTH, cx=BODY_CENTER_X):
    radius = width / 2.0
    half_line = (length - width) / 2.0
    return LineString([(cx - half_line, 0), (cx + half_line, 0)]).buffer(
        radius, quad_segs=48, cap_style="round"
    )


def ellipse(cx, cy, rx, ry):
    return affinity.scale(Point(cx, cy).buffer(1, quad_segs=48), rx, ry, origin=(cx, cy))


BODY = capsule()
EYELET_OUTER = ellipse(22.0, 0.0, 3.5, 4.5)
EYELET_INNER = ellipse(22.0, 0.0, 1.6, 2.5)
OUTLINE = unary_union([BODY, EYELET_OUTER]).difference(EYELET_INNER)
CAVITY = BODY.buffer(-WALL).intersection(box(-60, -30, 18.0, 30))


def extrude(poly, height, z=0.0):
    mesh = trimesh.creation.extrude_polygon(poly, height, engine="earcut")
    mesh.apply_translation([0, 0, z])
    return mesh


def cutter_box(extents, center):
    mesh = trimesh.creation.box(extents=extents)
    mesh.apply_translation(center)
    return mesh


def tray(depth, front=False, tongue=False):
    outer = extrude(OUTLINE, depth)
    cavity = extrude(CAVITY, depth - FLOOR + 0.4, FLOOR)
    mesh = trimesh.boolean.difference([outer, cavity], engine="manifold")

    cutters = [cutter_box([5.4, 3.0, 2.4], [-17.0, 10.2, depth - 1.1])]
    if front:
        cutters.extend(
            [
                trimesh.creation.cylinder(radius=0.65, height=FLOOR + 0.6, sections=48),
                trimesh.creation.cylinder(radius=0.55, height=FLOOR + 0.6, sections=48),
            ]
        )
        cutters[-2].apply_translation([-13.0, 0.0, (FLOOR + 0.6) / 2.0 - 0.2])
        cutters[-1].apply_translation([6.0, 0.0, (FLOOR + 0.6) / 2.0 - 0.2])

    mesh = trimesh.boolean.difference([mesh, *cutters], engine="manifold")

    if tongue:
        tongue_poly = BODY.buffer(-1.05).difference(BODY.buffer(-1.55)).intersection(
            box(-60, -30, 17.0, 30)
        )
        tongue_mesh = extrude(tongue_poly, 0.5, depth)
        mesh = trimesh.boolean.union([mesh, tongue_mesh], engine="manifold")

    mesh.remove_unreferenced_vertices()
    mesh.process(validate=True)
    return mesh


def component_box(name, extents, center, color):
    mesh = trimesh.creation.box(extents=extents)
    mesh.apply_translation(center)
    mesh.visual.face_colors = np.array(color, dtype=np.uint8)
    mesh.metadata["name"] = name
    return mesh


front = tray(FRONT_DEPTH, front=True)
back = tray(BACK_DEPTH, tongue=True)
front.export(ROOT / "front_shell.stl")
back.export(ROOT / "back_shell.stl")

# Assembled fit-check scene. The back shell is flipped onto the front shell.
scene = trimesh.Scene()
front_vis = front.copy()
front_vis.visual.face_colors = [185, 188, 192, 210]
scene.add_geometry(front_vis, node_name="6061 front shell")

back_vis = back.copy()
back_vis.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [1, 0, 0]))
back_vis.apply_translation([0, 0, FRONT_DEPTH + BACK_DEPTH])
back_vis.visual.face_colors = [35, 38, 42, 105]
scene.add_geometry(back_vis, node_name="polycarbonate rear shell")

components = [
    component_box("100mAh protected LiPo", [31.0, 11.5, 3.8], [-4.0, 0.0, 3.0], [235, 190, 60, 255]),
    component_box("XIAO nRF52840 Sense", [21.0, 17.5, 3.2], [-3.0, 0.0, 6.7], [45, 150, 90, 255]),
    component_box("motor driver", [5.0, 4.0, 1.0], [8.5, -6.0, 8.8], [70, 100, 180, 255]),
    component_box("side button", [5.0, 2.5, 2.0], [-17.0, 9.0, 6.2], [80, 80, 85, 255]),
]
motor = trimesh.creation.cylinder(radius=5.0, height=2.7, sections=64)
motor.apply_translation([13.0, 0.0, 7.6])
motor.visual.face_colors = [180, 105, 70, 255]
motor.metadata["name"] = "10mm haptic motor"
components.append(motor)

for comp in components:
    scene.add_geometry(comp, node_name=comp.metadata["name"])
scene.export(ROOT / "fit_check.glb")

# Simple, printable internal-layout drawing.
fig, ax = plt.subplots(figsize=(7.5, 4.4), dpi=180)
x, y = BODY.exterior.xy
ax.fill(x, y, color="#d9d9d6", alpha=0.8, label="51 × 21 mm shell")
xe, ye = EYELET_INNER.exterior.xy
ax.fill(xe, ye, color="white")

def rect(cx, cy, w, h, color, label):
    patch = plt.Rectangle((cx - w / 2, cy - h / 2), w, h, facecolor=color, edgecolor="#111", linewidth=0.8)
    ax.add_patch(patch)
    ax.text(cx, cy, label, ha="center", va="center", fontsize=7, color="white" if color != "#f2c94c" else "#111")

rect(-4.0, 0, 31.0, 11.5, "#f2c94c", "battery\nunder board")
rect(-3.0, 0, 21.0, 17.5, "#2f9e69", "XIAO\nabove battery")
motor_circle = plt.Circle((13.0, 0), 5.0, facecolor="#b66f46", edgecolor="#111")
ax.add_patch(motor_circle)
ax.text(13.0, 0, "haptic", ha="center", va="center", fontsize=7, color="white")

ax.annotate("51 mm maximum", xy=(-25.5, -13.5), xytext=(25.5, -13.5), ha="center", va="center",
            arrowprops=dict(arrowstyle="<->", color="#111"), fontsize=8)
ax.annotate("21 mm", xy=(-29, -10.5), xytext=(-29, 10.5), ha="center", va="center", rotation=90,
            arrowprops=dict(arrowstyle="<->", color="#111"), fontsize=8)
ax.text(0, 14.0, "Anticipy v0.1 internal fit", ha="center", fontsize=13, weight="bold")
ax.text(0, 11.8, "front aluminum · rear RF-transparent polycarbonate · 11 mm total depth", ha="center", fontsize=8)
ax.set_aspect("equal")
ax.set_xlim(-32, 28)
ax.set_ylim(-16, 16)
ax.axis("off")
fig.tight_layout()
fig.savefig(ROOT / "internal_layout.png", bbox_inches="tight", facecolor="white")
plt.close(fig)

for name, mesh in [("front", front), ("back", back)]:
    print(name, "bounds_mm=", np.round(mesh.bounds, 3).tolist(), "watertight=", mesh.is_watertight)
