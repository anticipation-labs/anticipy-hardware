# Lee NTR4101P local fallback — ACTIVE-LOW firmware

> **DANGER — DO NOT MIX HARDWARE OR FIRMWARE PATHS.**
>
> This UF2 is only for the Lee PID170433 NTR4101P **P-channel high-side**
> driver wired exactly below. It makes D0 electrically active-low. Never flash
> it onto the primary AO3400A/NMOS active-high circuit: the motor can remain
> energized when software believes it is off. Never flash the primary UF2 onto
> this P-channel circuit.

Status: **HOLD FOR PHYSICAL APP/HARDWARE RELEASE TESTS**.

## Flash only with this exact fallback circuit

| From | To |
|---|---|
| NTR4101P source | XIAO 3V3 |
| NTR4101P drain | Motor positive |
| Motor negative | XIAO GND |
| XIAO D0 | NTR4101P gate |
| 10 kohm pull-up | Gate to XIAO 3V3 |
| BAS16 cathode | Motor positive / NTR4101P drain |
| BAS16 anode | Motor negative / GND |

Confirm the actual SOT-23 pinout from the received NTR4101P manufacturer
marking/datasheet. The 10 kohm pull-up is the boot fail-safe that keeps the
P-FET off until firmware takes control.

## Artifact

- File: `HOLD_FOR_PHYSICAL_RELEASE_TEST_Anticipy_0.9.3_owner2_live_50mA_LOCAL_NTR4101P_ACTIVE_LOW.uf2`
- Size: 528,384 bytes
- SHA-256: `54b12eefb226d886ae374043ad2e5e409f5301956940de8bb13f76d084d14299`
- Board: `xiao_ble/nrf52840/sense`
- Application revision: `0.9.3-wed-live-bh-owner2`

The only source change from the packaged primary owner2 source is recorded in
`SOURCE_DIFF.patch`. Build and static-test evidence is in
`BUILD_AND_TEST_EVIDENCE.md`.

## Non-negotiable physical gates

- Prove motor off at boot, reset, commissioning, disconnect, system-off and
  watchdog recovery before connecting a battery.
- With the exact Renata 100640 installed, combined board-plus-motor draw must
  be no more than 160 mA peak and 80 mA continuous, with no reset or heat.
- Run haptic while BLE and audio are active; reject microphone buzz, RF loss,
  rubbing, driver/motor movement or abnormal temperature.
- Complete every line in `../../05_RELEASE/QA_RELEASE.md`; this binary is
  not released merely because it flashes.
