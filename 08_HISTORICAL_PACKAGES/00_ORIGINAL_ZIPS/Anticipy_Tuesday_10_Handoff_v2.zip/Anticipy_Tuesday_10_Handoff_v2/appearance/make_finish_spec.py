#!/usr/bin/env python3
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Anticipy_Cosmetic_Finish_Spec_v1.pdf"

regular = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
bold = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
pdfmetrics.registerFont(TTFont("AnticipySans", regular))
pdfmetrics.registerFont(TTFont("AnticipySansBold", bold))

PAGE_W, PAGE_H = landscape(letter)
INK = colors.HexColor("#151719")
MUTED = colors.HexColor("#62676B")
LINE = colors.HexColor("#D8DBDD")
PALE = colors.HexColor("#C7C9C8")
PALE_2 = colors.HexColor("#D3D4D3")
BLUE = colors.HexColor("#A9DBEE")


def para(text, size=7.8, leading=10.2, color=INK, bold_first=False):
    if bold_first and ":" in text:
        head, tail = text.split(":", 1)
        text = f"<b>{head}:</b>{tail}"
    return Paragraph(
        text,
        ParagraphStyle(
            "body",
            fontName="AnticipySans",
            fontSize=size,
            leading=leading,
            textColor=color,
            alignment=TA_LEFT,
            spaceAfter=0,
        ),
    )


def section(c, x, y, w, title, items):
    c.setFillColor(INK)
    c.setFont("AnticipySansBold", 9)
    c.drawString(x, y, title.upper())
    c.setStrokeColor(LINE)
    c.setLineWidth(0.6)
    c.line(x, y - 4, x + w, y - 4)
    rows = [[para(item, bold_first=True)] for item in items]
    table = Table(rows, colWidths=[w], rowHeights=None)
    table.setStyle(
        TableStyle(
            [
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    _, h = table.wrap(w, 300)
    table.drawOn(c, x, y - 10 - h)
    return y - 10 - h


def draw_front(c, x, y, scale=3.25):
    # Worn orientation: chain hole at top. Nominal face is 23 x 56 mm.
    fw = 23 * scale
    fh = 56 * scale
    radius = 7 * scale
    c.setFillColor(PALE)
    c.setStrokeColor(INK)
    c.setLineWidth(1.0)
    c.roundRect(x, y, fw, fh, radius, fill=1, stroke=1)

    # RF nose begins 32.46 mm below the top edge in the existing CAD.
    nose_h = (28 - 4.46) * scale
    c.saveState()
    path = c.beginPath()
    path.roundRect(x, y, fw, fh, radius)
    c.clipPath(path, stroke=0, fill=0)
    c.setFillColor(PALE_2)
    c.rect(x, y, fw, nose_h, fill=1, stroke=0)
    c.restoreState()

    seam_y = y + nose_h
    c.setStrokeColor(colors.HexColor("#8F9395"))
    c.setLineWidth(0.45)
    c.line(x, seam_y, x + fw, seam_y)

    # Features transformed from CAD: top edge is x=-28 mm.
    hole_y = y + (56 - 3.5) * scale
    button_y = y + (56 - 20.0) * scale
    logo_y = y + (56 - 27.5) * scale
    mic_y = y + (56 - 46.29) * scale
    led_y = y + (56 - 47.41) * scale

    c.setFillColor(colors.white)
    c.setStrokeColor(INK)
    c.setLineWidth(0.7)
    c.circle(x + fw / 2, hole_y, 2.1 * scale, fill=1, stroke=1)

    c.setFillColor(PALE_2)
    c.setStrokeColor(colors.HexColor("#777B7D"))
    c.circle(x + fw / 2, button_y, 1.7 * scale, fill=1, stroke=1)

    c.setFillColor(colors.HexColor("#4A4D4F"))
    c.setFont("AnticipySans", 5.1)
    label = "ANTICIPY"
    tw = c.stringWidth(label, "AnticipySans", 5.1)
    c.drawString(x + (fw - tw) / 2, logo_y - 1.6, label)

    c.setFillColor(INK)
    c.circle(x + fw * 0.91, mic_y, 0.55 * scale, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.setStrokeColor(colors.white)
    c.circle(x + fw * 0.08, led_y, 0.52 * scale, fill=1, stroke=1)

    # Dimension labels.
    c.setFillColor(MUTED)
    c.setFont("AnticipySans", 6.5)
    c.drawCentredString(x + fw / 2, y - 11, "FRONT - 56.0 x 23.0 mm")
    c.drawCentredString(x + fw / 2, y - 21, "Finished depth: 12.0 mm")
    c.drawCentredString(x + fw / 2, y - 31, "Hole at top")

    c.setStrokeColor(LINE)
    c.setDash(2, 2)
    c.line(x + fw + 7, logo_y, x + fw + 27, logo_y)
    c.setDash()
    c.setFillColor(MUTED)
    c.drawString(x + fw + 30, logo_y - 2, "13.00 mm outlined laser mark")
    c.line(x + fw + 7, seam_y, x + fw + 27, seam_y)
    c.drawString(x + fw + 30, seam_y - 2, "0.12 mm intentional hairline")


c = canvas.Canvas(str(OUT), pagesize=(PAGE_W, PAGE_H))
c.setTitle("Anticipy Cosmetic Finish Specification v1")
c.setAuthor("Anticipy")

margin = 30
c.setFillColor(INK)
c.setFont("AnticipySansBold", 18)
c.drawString(margin, PAGE_H - 36, "ANTICIPY")
c.setFont("AnticipySans", 10)
c.setFillColor(MUTED)
c.drawString(margin, PAGE_H - 52, "Cosmetic finish specification v1 - rush founder units")

# Top requirement band.
band_y = PAGE_H - 84
c.setFillColor(colors.HexColor("#F1F2F2"))
c.roundRect(margin, band_y, PAGE_W - 2 * margin, 22, 5, fill=1, stroke=0)
c.setFillColor(INK)
c.setFont("AnticipySansBold", 8)
c.drawString(margin + 10, band_y + 8, "56.0 x 23.0 x 12.0 mm")
c.drawString(margin + 160, band_y + 8, "5052 ALUMINUM + TRUE POLYCARBONATE")
c.drawString(margin + 405, band_y + 8, "PALE SATIN SILVER")
c.drawString(margin + 565, band_y + 8, "NO VISIBLE PRINT LAYERS")

# Accurate front view.
draw_front(c, 62, 68, 3.25)

col1_x = 292
col2_x = 535
col_w = 216
top_y = PAGE_H - 105

y1 = section(
    c,
    col1_x,
    top_y,
    col_w,
    "1. Materials",
    [
        "Metal faces: 0.60-0.65 mm 5052-H32 aluminum. Use pre-anodized satin silver for the Tuesday rush; no raw aluminum.",
        "Structure and RF nose: real opaque polycarbonate. The antenna end must remain completely nonconductive.",
        "Adhesive: 0.13 mm 3M 468MP or equivalent, cut to shape and set back at least 0.35 mm from every visible edge.",
    ],
)

y1 = section(
    c,
    col1_x,
    y1 - 14,
    col_w,
    "2. Pale silver appearance",
    [
        "Metal grain: fine, straight and parallel to the 56 mm long axis. No circular sanding, cross-grain, cloudy patches or raw cut faces.",
        "Polycarbonate color: solid non-metallic neutral silver-gray. Face-on match to the approved aluminum coupon under diffuse D65 light: Delta E00 <= 2.",
        "Gloss: PC satin 20 +/- 5 GU at 60 degrees. It should match the metal's visual softness, not imitate sparkle.",
    ],
)

section(
    c,
    col1_x,
    y1 - 14,
    col_w,
    "3. Brand mark",
    [
        "Artwork: use ANTICIPY_wordmark_13mm_outlined.svg exactly. Do not retype or substitute a font.",
        "Placement: horizontal center; mark center 27.5 mm below the top edge when worn. Finished width 13.00 mm.",
        "Tone: low-contrast neutral gray laser mark. No deep engraving, paint fill, raised vinyl or mark on the RF nose.",
    ],
)

y2 = section(
    c,
    col2_x,
    top_y,
    col_w,
    "4. Seams and edges",
    [
        "Face split: nominal 0.12 mm, maximum 0.18 mm. The silver frame must continue below it so the line never appears black.",
        "Flushness: aluminum-to-PC step <= 0.10 mm; perimeter mismatch <= 0.10 mm. No lifted corner, adhesive squeeze-out or visible glue.",
        "Edges: deburr and hand-break all aluminum edges 0.15-0.25 mm. Every touched edge must feel smooth and jewelry-safe.",
        "Sidewall: sand and finish the PC until no layer line is visible at 30 cm in diffuse light. Put the print seam on the rear side.",
    ],
)

y2 = section(
    c,
    col2_x,
    y2 - 14,
    col_w,
    "5. Visible details",
    [
        "Button: 3.4 mm circle, silver, centered and flush from 0.00 to 0.05 mm below the face. No wobble or rubbing.",
        "Chain opening: 4.2 mm clear diameter. Smooth the bore and hide every raw aluminum edge from the ring.",
        "Microphone: one clean 1.10 mm opening with black acoustic mesh behind it. No exposed green PCB.",
        "LED: one 1.04 mm frosted diffuser; soft ice-blue only. USB-C cutout must be crisp, centered and free of burrs.",
    ],
)

section(
    c,
    col2_x,
    y2 - 14,
    col_w,
    "6. Cosmetic release gate",
    [
        "Inspect each unit at 30 cm under 500 lux diffuse white light, then rotate it through all angles.",
        "Reject: visible layer line, black seam, adhesive, dent, burr, fingerprint under a face, color mismatch, crooked logo, loose button, rattle or sharp edge.",
        "RF rule: no metal, foil or conductive metallic coating anywhere on the PC nose. BLE range is checked after final closure.",
    ],
)

c.setStrokeColor(LINE)
c.line(margin, 26, PAGE_W - margin, 26)
c.setFont("AnticipySans", 6.3)
c.setFillColor(MUTED)
c.drawString(margin, 13, "Reference target: pale silver consumer-electronics finish. Anticipy geometry and branding remain distinct.")
c.drawRightString(PAGE_W - margin, 13, "Nominal body 56.0 x 23.0 x 12.0 mm - hard ceiling 56.1 x 23.1 x 12.1 mm")

c.showPage()
c.save()
print(OUT)
